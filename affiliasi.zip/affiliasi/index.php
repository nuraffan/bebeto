<?php 
require( "../config_sis.php" );

       if ( $_REQUEST['username'] == "" )
           {
	   header( "Location: ../index.php" );
	   }
       $username = trim( $_REQUEST['username'] );
       $password = trim( $_REQUEST['password'] );
       if ( $username == "" ) error( "Silahkan Isi Username dengan benar !!!" );
       if ( $password == "" ) error( "Password kosong, apakah anda lupa ???" );

       dbConnect();
       $result = mysql_query( "SELECT username FROM affiliasi WHERE username='$username'" ) or error( mysql_error() );
       if( mysql_num_rows( $result ) != 1 ) error( "Maaf, Username ini tidak ada dalam database kami" );
       $result = mysql_query( "SELECT username FROM affiliasi WHERE username='$username' AND passwd LIKE BINARY '$password'" ) or error( mysql_error() );
       if( mysql_num_rows( $result ) != 1 ) error( "Maaf, Password Salah !!! " );
       else
         {
          $status="nonaktif" ;
   	  $ukur = mysql_query( "SELECT username FROM affiliasi WHERE username='$username' AND stat1 LIKE BINARY '$status'" ) or error( mysql_error() );
	  if( mysql_num_rows( $ukur ) == 1 ) error( "Maaf, Status keanggotaan anda belum aktif atau sedang diblokir !!! " );
	  else
          {
    	 // session_register( "username" );
         // session_register( "password" );
	  $test = mysql_query("SELECT * from affiliasi where username='$username'")or error( mysql_error() );
          $datamember = mysql_fetch_array( $test );
	  $_SESSION[username1]=$datamember[1];
	  $_SESSION[password1]=$datamember[2];
	  $_SESSION[session_username]=$datamember[1];
	  $_SESSION[session_nama_member]=$datamember[3];
	  $_SESSION[session_email_member]=$datamember[4];
          $_SESSION[session_kota_member]=$datamember[6];
	  $_SESSION[session_hits]=$datamember[15];

		 
          header( "Location: affiliasi_area.php" );
          }
	  }


?>