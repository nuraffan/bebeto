<div class="container">
			
			<div class="logo">
				<h1 ><a href="affiliasi/index.php"><b>T<br>H<br>
				E</b>bebeto<span>PASAR TRADISIONAL</span></a></h1>
			</div>
			<div class="head-t">
				<ul class="card">
					<li><a href="affiliasi_area.php" ><i class="fa fa-home" aria-hidden="true"></i>Home</a></li>
					<li><a href="about.html" ><i class="fa fa-clock-o" aria-hidden="true"></i>History</a></li>
					<li><a href="register.html" ><i class="fa fa-question" aria-hidden="true"></i>Help</a></li>
					<li><a href="setting.php" ><i class="fa fa-gear" aria-hidden="true"></i>Settings</a></li>
					<!--<li><a href="shipping.html" ><i class="fa fa-ship" aria-hidden="true"></i>Shipping</a></li>-->
				</ul>	
			</div>
			
			
					<div class="clearfix"></div>