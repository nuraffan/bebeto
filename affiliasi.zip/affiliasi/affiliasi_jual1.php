<?php 

dbConnect();
if( !verifyUser() ) header( "Location: ../index.php" );
$halaman = "20" ;
$paid = "paid";
  $nilai = mysql_query( "SELECT * FROM admin_affiliasi WHERE kode='$kode'" ) or error( mysql_error() );
  $data = mysql_fetch_array( $nilai );
  $result = mysql_query( "SELECT * FROM customer where username_sponsor='$_SESSION[session_username]' AND paid='$paid' ORDER BY order_id DESC" ) or error( mysql_error() );
  $memnum = mysql_num_rows( $result );
  $jmlhalaman = ceil(mysql_num_rows($result) / $halaman);
	
  $AFFILIASI = $data['harga_produk'] * $data['bonus_affiliasi'] / 100;
  $RUPIAH_AFFILIASI = rupiah($AFFILIASI);	    
  $BONUS = $AFFILIASI * $memnum;
  $RUPIAH_BONUS = rupiah($BONUS);
	error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
  if($_GET['page'])
	{
	$page = $_GET['page'];
	}
  else
	{
	$page = 0;
	}
    $offset = $page * $halaman;
    $resul = mysql_query( "SELECT * FROM customer where username_sponsor='$_SESSION[session_username]' AND paid='$paid' ORDER BY order_id DESC LIMIT $offset, $halaman" ) or error( mysql_error() );
		
	if( $memnum != 0 )
	{
	 
	echo "<p style=\"margin-top: 0; margin-bottom: 0\" align=\"center\"><font size=\"2\">Listing hasil penjualan anda : <b>$memnum pembeli,</b> </font></p>\n";
	echo "<p style=\"margin-top: 0; margin-bottom: 0\" align=\"center\"><font size=\"2\"><b>Estimasi</b> Bonus anda adalah : $RUPIAH_AFFILIASI x $memnum = <b>$RUPIAH_BONUS</b></font></p>\n";
	echo "<div align=\"center\"><small>\n";
	echo '<table id="text" style="width:100%;">';
	echo '<tr style="background:#C0C0C0;"><td>';
	echo '<small>NAMA</small></td><td><small>KOTA</small></td><td><small>ALAMAT</small></td><td><small>TGL. ORDER</small></tr>';

        $i = 1;
	while( $row = mysql_fetch_array( $resul ) )
	{
          $i % 2 == 0 ? $bgColor = "#FFFFFF" : $bgColor = "#E6E6E6";
           //$nilai_rupiah = rupiah($row[rupiah_sponsor1]);
	  echo '<tr><td><small>',$row[nama],'</small></td>';
	  echo '<td><small>',$row[kota],'</small></td>';
	  echo '<td><small>',$row[alamat],'</small></td>';
	  echo '<td><small>',$row[tanggal_join],'</small></td>';
            $i=$i+1;
 		}
          echo '<tr style="background:#C0C0C0;"><td>';
	  echo '<small>NAMA</small></td><td><small>KOTA</small></td><td><small>ALAMAT</small></td><td><small>TGL. ORDER</small></tr>';

          echo '</table><br>';
	
	echo "<b>Halaman :</b>\n";
	for($a=0;$a<$jmlhalaman;$a++)
	    {
		echo" [<a href='affiliasi_jual.php?page=$a'>$a</a>]\n";
     	}
		
 	    }
		else
		{ 	
	    echo "<p align=\"center\"><b>Maaf !!! , Anda belum berhasil menjual apapun dari produk kami.</b></a></p>\n";
	    //exit;
	    }
		 	
?>