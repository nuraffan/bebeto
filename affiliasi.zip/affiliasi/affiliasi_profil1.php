<?php 

require( "../config_sis.php" );
dbConnect();
if( !verifyUser() ) header( "Location: ../index.php" );

$passwd=ltrim($_POST['passwd']);
$nama=ltrim($_POST['nama']);
$email=ltrim($_POST['email']);
$alamat=ltrim($_POST['alamat']);

$telpon=ltrim($_POST['telpon']);
$bank=ltrim($_POST['bank']);
$cabang_bank=ltrim($_POST['cabang_bank']);
$rekening=ltrim($_POST['rekening']);

  // if( $username == "" ) error( "Username Kosong !!! Harus Login Kembali" );
   dbConnect();
   $nilai = mysql_query( "SELECT * FROM admin_affiliasi WHERE kode='$kode'" ) or error( mysql_error() );
   $data = mysql_fetch_array( $nilai );
   if( mysql_num_rows( $nilai ) != 1 ) error( "Ops ... ! Maaf Data administrator tidak ada !!!  " );
   $result = mysql_query( "SELECT username FROM affiliasi WHERE username='$_SESSION[session_username]'" ) or error( mysql_error() );
   $reseller = mysql_fetch_array( $result );
   //if( mysql_num_rows( $result ) != 1 ) error( "Maaf, Username tidak anda" );

   if( $passwd == "" ) error( "Ops... Passwordnya harus diisi !!!" );
   if( $nama == "" ) error( "Ops... Nama harus isi !!!" );
   if( $alamat == "" ) error( "Ops... Alamat harus diisi !!!" );
   
   if( $email == "" ) error( "Ops... Email anda Harus diisi !!! " );
   if( $telpon == "" ) error( "Telpon harus isi !!!" );
   if( $bank == "" ) error( "Nama Bank Wajib diisi !!!" );
   if( $cabang_bank == "" ) error( "Cabang Bank Wajib diisi !!!" );
   if( $rekening == "" ) error( "Rekening Bank Wajib diisi !!!" );
   if ( !eregi( "^[0-9a-z]([-_.]?[0-9a-z])*@[0-9a-z]([-.]?[0-9a-z])*\\.[a-z]{2,3}$", $email ) ) error( "Oops !!!!.. data Email anda Invalid alias tidak sah !!!" );

   mysql_query( "UPDATE affiliasi SET passwd='$passwd', nama='$nama', email='$email', alamat='$alamat', telpon='$telpon', nama_bank='$bank', cabang_bank='$cabang_bank', rekening='$rekening' WHERE username='$_SESSION[session_username]' " ) or error( mysql_error() );

         // --- Kirim email Konfirmasi kasil editing ke member
         // --- PERHATIAN !!! Untuk mencegah error Jangan Ganti Variabel yang berawalan tanda "$"  

$subject_1 = "Hasil Editing Profil anda ";
$message_1 = "
Hallo $nama , Anda telah melakukan Edit Profil anda di affiliasi area
****************************************************
Berikut ini adalah data yang telah anda edit :
****************************************************
Username          : $_SESSION[session_username]
Password          : $passwd
Nama              : $nama
email             : $email 
Alamat            : $alamat 

Telpon	          : $telpon 
Nama Bank         : $bank 
Cabang Bank       : $cabang_bank 
Rekening          : $rekening 
*******************[TERIMA KASIH]********************
Terima Kasih Harap disimpan baik-baik data ini 
*****************************************************
		    
Salam Sukses 
$data[nama_bisnis] 
$data[nama_admin] 
$data[alamat_admin] 
$data[telpon_admin] 
   
 ";
$pesanBaru_1 = "----------------------->>$data[website]<<-----------------------------\n\n" . $message_1 . "\n\n";
sentMail( "$data[nama_bisnis] <$data[email_admin]>", $email, $subject_1, $pesanBaru_1 );

error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
  
         $test = mysql_query("SELECT * from affiliasi where username='$_SESSION[session_username]'")or error( mysql_error() );
         $datamember = mysql_fetch_array( $test );
         $_SESSION[username]=$datamember[1];
	 $_SESSION[password]=$datamember[2];
	 $_SESSION[session_username]=$datamember[1];
	 $_SESSION[session_nama_member]=$datamember[3];
	 $_SESSION[session_email_member]=$datamember[4];
         $_SESSION[session_kota_member]=$datamember[6];
	 $_SESSION[session_hits]=$datamember[15];
 

?>