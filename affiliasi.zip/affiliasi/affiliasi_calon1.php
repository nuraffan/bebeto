<?php 
dbConnect();
if( !verifyUser() ) header( "Location: ../index.php" );
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
$halaman = "20" ;
$paid = "nopaid";
  $nilai = mysql_query( "SELECT * FROM admin_affiliasi WHERE kode='$kode'" ) or error( mysql_error() );
  $data = mysql_fetch_array( $nilai );
  $result = mysql_query( "SELECT * FROM customer where username_sponsor='$_SESSION[session_username]' AND paid='$paid' ORDER BY order_id DESC" ) or error( mysql_error() );
  $memnum = mysql_num_rows( $result );
  $jmlhalaman = ceil(mysql_num_rows($result) / $halaman);
	
  //$AFFILIASI = $data[harga_produk] * $data[bonus_affiliasi] / 100;
  //$RUPIAH_AFFILIASI = rupiah($AFFILIASI);	    
  //$BONUS = $AFFILIASI * $memnum;
  //$RUPIAH_BONUS = rupiah($BONUS);
	
  if($_GET['page'])
	{
	$page = $_GET['page'];
	}
  else
	{
	$page = 0;
	}
    $offset = $page * $halaman;
    $resul = mysql_query( "SELECT * FROM customer where username_sponsor='$_SESSION[session_username]' AND paid='$paid' ORDER BY order_id DESC LIMIT $offset, $halaman" ) or error( mysql_error() );
		
	if( $memnum != 0 )
	{
	 
	echo "<p style=\"margin-top: 0; margin-bottom: 0\" align=\"center\"><font size=\"2\">Listing calon vendor dari GOPATRA</font></p>\n";
	echo "<p style=\"margin-top: 0; margin-bottom: 0\" align=\"center\"><font size=\"2\">Calon vendor ini <b>BELUM</b> melakukan pembayaran pada GOPATRA</font></p>\n";
	echo "<div align=\"center\"><small>\n";
	echo '<table id="text" style="width:100%;">';
	echo '<tr style="background:#C0C0C0;"><td>';
	echo '<b>NAMA</td><td>KOTA</td><td>ALAMAT</td><td>TGL. ORDER</td><td>STATUS</b></tr>';

        $i = 1;
	while( $row = mysql_fetch_array( $resul ) )
	{
          $i % 2 == 0 ? $bgColor = "#FFFFFF" : $bgColor = "#E6E6E6";
           //$nilai_rupiah = rupiah($row[rupiah_sponsor1]);
	  echo '<tr><td>',$row[nama],'</td>';
	  echo '<td>',$row[kota],'</td>';
	  echo '<td>',$row[alamat],'</td>';
	  echo '<td>',$row[tanggal_join],'</td>';
	  echo '<td>',$row[paid],'</td>';
            $i=$i+1;
 		}
          echo '<tr style="background:#C0C0C0;"><td>';
	  echo 'NAMA</td><td>KOTA</td><td>ALAMAT</td><td>TGL. ORDER</td><td>STATUS</tr>';

          echo '</table><br>';
	
	echo "<b>Halaman :</b>\n";
	for($a=0;$a<$jmlhalaman;$a++)
	    {
		echo" [<a href='affiliasi_calon.php?page=$a'>$a</a>]\n";
     	}
		
 	    }
		else
		{ 	
	    echo "<p align=\"center\"><b>Maaf !!! , Anda tidak punya calon pembeli</b></a></p>\n";
	    //exit;
	    }
		 	
?>