<?php 
//error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
if( !verifyUser() ) header( "Location: ../index.php" );
$bayar_bonus = ltrim($_POST['bayar_bonus']);
$user1 = ltrim($_POST['user1']);

$nilai = mysql_query( "SELECT * FROM admin_affiliasi WHERE kode='$kode'" ) or error( mysql_error() );
$data = mysql_fetch_array( $nilai );
$paid = "paid";
$result1 = mysql_query( "SELECT * FROM customer where username_sponsor='$_SESSION[username]' AND paid='$paid' " ) or error( mysql_error() );
$jumlah_member = mysql_num_rows( $result1 );
$test = mysql_query("SELECT * from affiliasi where username='$_SESSION[username]'")or error( mysql_error() );
$datamember = mysql_fetch_array( $test );

$AFFILIASI = $data['harga_produk'] * $data['bonus_affiliasi'] / 100;

$rupiah_affiliasi = rupiah($AFFILIASI);
$rupiah_bonus_cair = rupiah($data['bonus_cair']);
$total_bonus = $jumlah_member * $AFFILIASI;
$rupiah_total_bonus = rupiah($total_bonus);

$bonus_terbayar = $datamember['bonus_terbayar'] ;
$sisa_bayar_total = $total_bonus - $bonus_terbayar ;
$rupiah_bonus_terbayar = rupiah($bonus_terbayar);
$rupiah_sisa_bayar_total = rupiah($sisa_bayar_total);

if( $sisa_bayar_total < $data['bonus_cair'] ) error( "Maaf ... !!!! Bonus anda belum mencapai batas minimal dari persyaratan, Yaitu Minimal $rupiah_bonus_cair !!!  " );	

         // --- Kirim email Konfirmasi komplain bonus ke Pengelola
         // --- PERHATIAN !!! Untuk mencegah error Jangan Ganti Variabel yang berawalan tanda "$"  

$subject_1 = "Permintaan Pembayaran Bonus $datamember[nama] ";
$message_1 = "
Permintaan Pembayaran bonus dari member nama : $datamember[nama] 

Jumlah Total Bonus yang diminta : $rupiah_sisa_bayar_total

****************************************************
Berikut ini adalah data dari yang bersangkutan :
****************************************************
Username          : $datamember[username]
Password          : $datamember[passwd]
Nama              : $datamember[nama]
email             : $datamember[email]
Alamat            : $datamember[alamat]
Kota              : $datamember[kota]
Telpon	          : $datamember[telpon]
Nama Bank         : $datamember[nama_bank]
Cabang Bank       : $datamember[cabang_bank]
Rekening          : $datamember[rekening]
Bonus yang sudah terbayar : $rupiah_bonus_terbayar 
 
*******************[TERIMA KASIH]********************
DEMIKIAN DATA INI DISAMPAI UNTUK MENJADI PERHATIAN 
*****************************************************
		    
Salam Sukses 
$data[nama_bisnis] 
$data[nama_admin] 
$data[alamat_admin] 
$data[telpon_admin] 
   
 ";
$pesanBaru_1 = "----------------------->>$data[website]<<-----------------------------\n\n" . $message_1 . "\n\n";
sentMail( "$datamember[nama] <$datamember[email]>", $data[email_admin], $subject_1, $pesanBaru_1 );

 


?>