<?php
include "../config_sis.php";
dbConnect();
if( !verifyUser() ) header( "Location: ../index.php" );
require( "affiliasi_area_a.php" );
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php 
include "head.php";
?>
</head>
<body>
<body>
<a href="offer.html"><img src="../images/download.png" class="img-head" alt=""></a>
<div class="header">
<?php include "menu_user.php";
?>
<?php include "menu_aff.php"; ?>
</div>
</body>
</html>
