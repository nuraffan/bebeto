<?php 
$nilai = mysql_query( "SELECT * FROM admin_affiliasi WHERE kode='$kode'" ) or error( mysql_error() );
$data = mysql_fetch_array( $nilai );
$paid = "paid";
$result1 = mysql_query( "SELECT * FROM customer where username_sponsor='$_SESSION[session_username]' AND paid='$paid' " ) or error( mysql_error() );
$jumlah_member = mysql_num_rows( $result1 );
$test = mysql_query("SELECT * from affiliasi where username='$_SESSION[session_username]'")or error( mysql_error() );
$datamember = mysql_fetch_array( $test );

$AFFILIASI = $data['harga_produk'] * $data['bonus_affiliasi'] / 100;

$rupiah_affiliasi = rupiah($AFFILIASI);
$rupiah_bonus_cair = rupiah($data['bonus_cair']);
$total_bonus = $jumlah_member * $AFFILIASI;
$rupiah_total_bonus = rupiah($total_bonus);

$bonus_terbayar = $datamember['bonus_terbayar'] ;
$sisa_bayar_total = $total_bonus - $bonus_terbayar ;
$rupiah_bonus_terbayar = rupiah('$bonus_terbayar');
$rupiah_sisa_bayar_total = rupiah($sisa_bayar_total);


?>