<?php
dbConnect();
$nilai = mysql_query( "SELECT * FROM admin_affiliasi WHERE kode='$kode'" ) or error( mysql_error() );
$data1 = mysql_fetch_array( $nilai );
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>MENU AFFILIASI AREA</TITLE>
<META http-equiv=Content-Type content="text/html; charset=iso-8859-1">
<META content=eI1k3fMlm3MqcHJPZ2NL/S31bc6o86wklMFhapB9NLA= name=verify-v1>
<META http-equiv=Content-Language content=en-us>
<META content=7days name=revisit-after>
<META content="index, follow" name=robots><LINK 
href="../images/style.css" 
type=text/css rel=stylesheet>
<META content="Microsoft FrontPage 5.0" name=GENERATOR></HEAD>
<BODY bgColor=#FFFFFF leftMargin=0 topMargin=0 marginwidth="0" marginheight="0">
<SCRIPT>
  <!-- Hide from old browsers

 message     =  "Sebuah Solusi finansial anda terhampar didepan mata .....^" +
                "Sebuah bisnis yang praktis serta cepat menghasilkan uang^" +
                "Segera gabung bersama kami untuk menciptakan MESIN UANG secara online di internet^" +
                "^"
  scrollSpeed = 25
  lineDelay   = 1500

  // Do not change the text below //

  txt         = ""

  function scrollText(pos) {
    if (message.charAt(pos) != '^') {
      txt    = txt + message.charAt(pos)
      status = txt
      pauze  = scrollSpeed
    }
    else {
      pauze = lineDelay
      txt   = ""
      if (pos == message.length-1) pos = -1
    }
    pos++
    setTimeout("scrollText('"+pos+"')",pauze)
  }

  // Unhide -->
scrollText(0)
  </SCRIPT>

<A name=top></A>
<TABLE cellSpacing=0 cellPadding=0 width=179 align=center border=0>
  <TBODY>
  <TR>
    <TD width="1">
      <TABLE cellSpacing=0 cellPadding=0 width="177" border=0>
        <TBODY>
        <TR>
          <TD vAlign=top width=178 bgColor=#f5f5f5 height=264>
            <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
              <TBODY>
              <TR>
                <TD><!--Main Menu-->
                  <TABLE cellSpacing=0 cellPadding=0 border=0>
                    <TBODY>
                    <TR>
                      <TD vAlign=top>
                        <DIV id=b2>
                        <UL>
                          <LI>
                          <DIV class=bhz style="width: 173; height: 22">
                            <p style="text-align: center"><span class="hw2">::&nbsp;MENU 
                            AFFILIASI&nbsp;::</span></DIV>
                          <LI><a title="Home" href="affiliasi_area.php">Home</a> 

                          <LI>
                          <a title="Edit Profil anda ..!" href="affiliasi_profil.php">Profil 
                          Anda</a></span> 

                          <LI>
                          <a title="Laporan Hasil Penjualan anda" href="affiliasi_jual.php">Data Profit </a></span> 

                          <LI>
                          <a title="Listing Calon pembeli referensi anda" href="affiliasi_calon.php">Calon Vendor </a></span></LI>
                          <!--<LI>
                          <a title="Beberapa banner untuk promosi" href="affiliasi_banner.php">Banner Promosi</a> 
                          <LI>-->
						  <li>
                          <a title="Untuk melihat statistik kunjungan web anda" href="affiliasi_statistik.php">Statistik kunjungan</a></li>
                          <LI>
                          <a title="keluar Affiliasi Area KLIK DISINI" href="affiliasi_logout.php">L O G O U T</a></UL></DIV></TD></TR></TBODY></TABLE><!--End Main Menu--></TD></TR>
              <tr>
                <TD vAlign=center align=middle 
                background="../images/btn.jpg" 
                height=30>
                  <p class="tanda"><font color="#000066">ADMIN CONTACT</font></TD>
              </tr>
              <TR>
                <TD class=tekskecil vAlign=top align=middle height=90>
                  <p style="margin-top: 0; margin-bottom: 0" align="center">
                    <img src="../images/logo.png" width="97" height="98" border="0"></p>
                    <p style="margin-top: 0; margin-bottom: 0" align="center">
                    <font face="Verdana" style="font-size: 9pt; font-weight: 700">
                    Nama : <?php echo"$data1[nama_admin]" ?></font></p>
                    <p style="margin-top: 0; margin-bottom: 0" align="center">
                    <font face="Verdana" style="font-size: 9pt">E-Mail :</font></p>
                    <p style="margin-top: 0; margin-bottom: 0" align="center">
                    <font face="Verdana" style="font-size: 9pt">&nbsp;<b><?php echo"$data1[email_admin]" ?></b></font></p>
                    <p style="margin-top: 0; margin-bottom: 0" align="center">
                    <font face="Verdana" style="font-size: 8pt"><?php echo"$data1[alamat_admin]" ?></font></p>
                    <p style="margin-top: 0; margin-bottom: 0" align="center">
                    <font face="Verdana" style="font-size: 8pt">Phone : 
                    <?php echo"$data1[telpon_admin]" ?></font></p>
                     <p style="margin-top: 0; margin-bottom: 0" align="center">
                    <font face="Verdana" color="#008080" style="font-size: 8pt">
                    <?php echo"$data1[website]" ?></font></p>
                  &nbsp;<p>&nbsp;</p>
                <p>&nbsp;</p>
                <p></TD></TR></TBODY></TABLE></TD>
          </TR></TBODY></TABLE></TD>
    </TR>
  </TBODY></TABLE><IMG 
height=1 src="" width=1 border=0>&nbsp;&nbsp; </BODY></HTML>