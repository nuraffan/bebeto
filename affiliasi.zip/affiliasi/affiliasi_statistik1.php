<?php 
dbConnect();
if( !verifyUser() ) header( "Location: ../index.php" );
$halaman = "50" ;
  $nilai = mysql_query( "SELECT * FROM admin_affiliasi WHERE kode='$kode'" ) or error( mysql_error() );
  $data = mysql_fetch_array( $nilai );
  $result = mysql_query( "SELECT * FROM statistik where username='$_SESSION[session_username]' ORDER BY user_id DESC" ) or error( mysql_error() );
  $memnum = mysql_num_rows( $result );
  $jmlhalaman = ceil(mysql_num_rows($result) / $halaman);
	
  //$AFFILIASI = $data[harga_produk] * $data[bonus_affiliasi] / 100;
  //$RUPIAH_AFFILIASI = rupiah($AFFILIASI);	    
  //$BONUS = $AFFILIASI * $memnum;
  //$RUPIAH_BONUS = rupiah($BONUS);
	error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
  if($_GET['page'])
	{
	$page = $_GET['page'];
	}
  else
	{
	$page = 0;
	}
    $offset = $page * $halaman;
    $resul = mysql_query( "SELECT * FROM statistik where username='$_SESSION[session_username]' ORDER BY user_id DESC LIMIT $offset, $halaman" ) or error( mysql_error() );
		
	if( $memnum != 0 )
	{
	echo "<p style=\"margin-top: 0; margin-bottom: 0\" align=\"center\"><font size=\"2\"><b>STATISTIK KUNJUNGAN LINK AFFILIASI ANDA </b> </font></p>\n";
	echo "<p style=\"margin-top: 0; margin-bottom: 0\" align=\"center\"><font size=\"2\"><b>Total</b> kunjungan saat ini adalah : <b>$memnum</b> x</font></p>\n";
	echo "<div align=\"center\"><small>\n";
	echo '<table id="text" style="width:100%;">';
	echo '<tr style="background:#C0C0C0;"><td>';
	echo '<small>WAKTU</small></td><td><small>IP</small></td><td><small>URL</small></td><td><small>REFERENSI DATANGNYA KLIK</small></tr>';

        $i = 1;
	while( $row = mysql_fetch_array( $resul ) )
	{
          $i % 2 == 0 ? $bgColor = "#FFFFFF" : $bgColor = "#E6E6E6";
           //$nilai_rupiah = rupiah($row[rupiah_sponsor1]);
	  echo '<tr><td><small>',$row[time],'</small></td>';
	  echo '<td><small>',$row['ip_add'],'</small></td>';
	  echo '<td><small>',$row['url'],'</small></td>';
	  echo '<td><small>',$row['ref'],'</small></td>';
	  //echo '<td><small>'. date( "d-m-y", $row['tanggal_join'] ) .'</small></td>';
            $i=$i+1;
 		}
          echo '<tr style="background:#C0C0C0;"><td>';
	 echo '<small>WAKTU</small></td><td><small>IP</small></td><td><small>URL</small></td><td><small>REFERENSI DATANGNYA KLIK</small></tr>';

          echo '</table><br>';
	
	echo "<b>Halaman :</b>\n";
	for($a=0;$a<$jmlhalaman;$a++)
	    {
		echo" [<a href='affiliasi_statistik.php?page=$a'>$a</a>]\n";
     	}
		
 	    }
		else
		{ 	
	    echo "<p align=\"center\"><b>Maaf !!! , Belum ada kunjungan ke web anda </b></a></p>\n";
	    //exit;
	    }
		 	
?>