<?php 
// #-------------------------- Script Indo Affiliate 2008 Ver 1.0 ---------------#
// #------------------------ http://www.superautopilot.com  ---------------------#
// #----------------------- Protected By Indonesian Law  ------------------------#
     session_start();
	 session_destroy();
	 unset($_SESSION[username]);
	 unset($_SESSION[password]);
	 unset($_SESSION[session_username]);
	 unset($_SESSION[session_nama_member]);
	 unset($_SESSION[session_email_member]);
     unset($_SESSION[session_kota_member]);
	 unset($_SESSION[session_hits]);

         header( "Location: ../index.php" );

;echo '


';
?>