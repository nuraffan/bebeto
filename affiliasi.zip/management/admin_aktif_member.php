<?php

	require( "../config_sis.php" );
	if( !verifyAdmin() ) 
	{
	header( "Location: index.php" );
	return false;
	}
	//if( !verifyAdmin() ) header( "Location: index.php" );
	dbConnect();
	$nilai = mysql_query( "SELECT * FROM admin_affiliasi WHERE kode='$kode'" ) or error( mysql_error() );
        $data = mysql_fetch_array( $nilai );
        if( mysql_num_rows( $nilai ) != 1 ) error( "Ops ... ! Maaf Data administrator tidak ada, silahkan kontak pengelola website ini " );
        $halaman = "20" ;
   	$paid="nopaid";
        $stat="nonaktif";
	$result = mysql_query( "SELECT * FROM customer WHERE paid='$paid' AND stat='$stat' ORDER BY order_id DESC" ) or error( mysql_error() );
	$memnum = mysql_num_rows( $result );
	$jmlhalaman = ceil(mysql_num_rows($result) / $halaman);
	
	
	if(!isset($page))
	{
		$page = 0;
	}
	$offset = $page * $halaman;
	$resul = mysql_query( "SELECT * FROM customer where paid='$paid' AND stat='$stat' ORDER BY order_id DESC LIMIT $offset, $halaman" ) or error( mysql_error() );
	
	
	displayHeader( "Admin > Member List" );
    echo " <p style=\"margin-top: 0; margin-bottom: 0\" align=\"center\"><font size=\"1\"> Tampilan Member yang belum aktif (No Paid). Untuk Mengaktifkan klik menu <b>'Aktifkan'</b>, maka secara otomatis website member akan aktif dan bisa masuk member area  </p> \n";
    echo "<p style=\"margin-top: 0; margin-bottom: 0\" align=\"center\"><font size=\"2\">Total member yang belum aktif = $memnum </font></p>\n";
	if( $memnum != 0 )
	{
	    echo "<div align=\"center\"><small>\n";
	    echo "  <center>\n";
	    echo "  <table border=\"0\" cellspacing=\"0\" width=\"800\" cellpadding=\"5\">\n";
	    echo "    <tr class=\"frame\">\n";
	    echo "      <td width=\"8%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#FFFFFF\"><b>Order_ID</b></font></small></td>\n";
	    echo "      <td width=\"13%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#FFFFFF\"><b>Nama</b></font></small></td>\n";
	    echo "      <td width=\"15%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#FFFFFF\"><b>email</b></font></small></td>\n";
	    echo "      <td width=\"13%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#FFFFFF\"><b>Bank</b></font></small></td>\n";
        echo "      <td width=\"10%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#FFFFFF\"><b>Rekening</b></font></small></td>\n";
	    echo "      <td width=\"12%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#FFFFFF\"><b>Pengelola</b></font></small></td>\n";
        echo "      <td width=\"12%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#FFFFFF\"><b>Sponsor  </b></font></small></td>\n";
	    echo "      <td width=\"10%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#FFFFFF\"><b>Tgl Join</b></font></small></td>\n";
	    echo "      <td width=\"7%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#FFFFFF\"><b>Aktifkan ?</b></font></small></td>\n";
	    echo "    </tr>\n";
		$i = 1;
		while( $row = mysql_fetch_array( $resul ) )
		{
		error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
			$i % 2 == 0 ? $bgColor = "#FFFFFF" : $bgColor = "#E6E6E6";
			$rupiah_pengelola = rupiah($row['rupiah_master']);
		 	//$adsnum = mysql_num_rows( mysql_query( "SELECT user_name FROM member WHERE user_name={$row['user_name']}" ) );
		 	echo "    <tr>\n";
            echo "      <td width=\"8%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">{$row['order_id']}</td>\n";
	        echo "      <td width=\"13%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">{$row['nama']}</td>\n";
	        echo "      <td width=\"15%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">{$row['email']}</td>\n";
	        echo "      <td width=\"13%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">{$row['nama_bank']}</td>\n";
            echo "      <td width=\"10%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">{$row['rekening']}</td>\n";
			echo "      <td width=\"12%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">{$row['rupiah_pembelian']}</td>\n";
            echo "      <td width=\"12%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">{$row['username_sponsor']}</td>\n";
            echo "      <td width=\"10%\" height=\"25\" align=\"leftr\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">{$row['tanggal_join']}</td>\n";
            echo "      <td width=\"7%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\"><a href='admin_aktif_member1.php?email={$row['email']}'>Aktifkan<font size=\"1\"></td>\n";
            echo "    </tr>\n";
 			$i++;
 		}
		echo "<b>Halaman :</b>\n";
		for($a=0;$a<$jmlhalaman;$a++)
	    {
		echo" [<a href='admin_aktif_member.php?page=$a'>$a</a>]\n";
     	}
 		echo "    <tr>\n";
 		echo "      <td width=\"100%\" height=\"1\" bgcolor=\"#808080\" colspan=\"10\"></td>\n";
 		echo "    </td>\n";
 	    echo "  </table>\n";
 	 	echo " </center>\n";
		echo "</div></small>\n";
	}
	//echo "<p align=\"center\"><a href=\"admin_menu.php\"><b>Back to Admin</b></a></p>\n";
?>
