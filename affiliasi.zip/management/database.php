<?php


//Variable server & Admin

   $ADVT_NAME = "CMS Script Website Instant";   // Headline bisnis anda
    $dbHost = "localhost";                        // Database host
    $dbName = "affiliate_cms";                        // Database name
    $dbUser = "root";                             // Database user
    $dbPasswd = "";                               // Database password
    $kode = "admin";                              // Kode Kunci database admin
    $PAGE_BG_COLOR = "#FFFFFF";                   // Page background color
    $PAGE_BG_IMAGE = "";                          // Page backgouund image, leave blank if none

// Variable fungsi randomizer
// Untuk membuat sponsor acak random, masukkan variable $random = "1"
// Sedang untuk mematikan fungsi random masukkan variable $random = "0"
// Jika web tidak random maka sebagai affiliasi default adalam member perdana yang
// di input saat install.

   //$random = "0" ;

?>
