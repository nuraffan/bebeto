<?php 

	require( "../config_sis.php" );
    if( !verifyAdmin() ) 
	{
	header( "Location: ../index.php" );
	return false;
	}
    if ($_GET['user'])
	{
    dbConnect();
	$result = mysql_query( "SELECT * FROM affiliasi where username='$_GET[user]'" ) or error( mysql_error() );
    $reseller = mysql_fetch_array( $result );
	
	$nilai = mysql_query( "SELECT * FROM admin_affiliasi WHERE kode='$kode'" ) or error( mysql_error() );
    $data = mysql_fetch_array( $nilai );
    $AFFILIASI = $data["harga_produk"] * $data["bonus_affiliasi"] / 100;
    $RUPIAH_AFFILIASI = rupiah($AFFILIASI);
    if( mysql_num_rows( $nilai ) != 1 ) error( "Ops ... ! Maaf Data administrator tidak ada !!!  " );
    $status="aktif";
    mysql_query( "UPDATE affiliasi SET stat1='$status' WHERE username='$_GET[user]' " ) or error( mysql_error() );
      
    require ("../email/email_aktivasi_affiliasi_lagi.php");
        
        
        displayHeader( "Admin :: Aktivasi Affiliasi" );
        echo "<p align=\"center\"><font size=\"2\">::: Mengaktifkan Member Affiliasi Dengan Username : <b>$_GET[user]</b> Telah Sukses !!! :::</font></p>\n";
        //echo "<p align=\"center\"><a href=\"admin_menu.php\"><b>Back to Admin</b></a></p>\n";

        }
	
;echo '
';
?>