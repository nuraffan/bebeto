<?
require( "../config_sis.php" );
if( !verifyAdmin() ) 
	{
	header( "Location: index.php" );
	return false;
	}
?>

<html>

<head>
<title>:: Management Area ::</title>
<link rel="stylesheet" href="styles.css" type="text/css">
<style>
td {padding-bottom:5px; border-bottom: 1px solid #CCCCCC;}
</style>
</head>
<body>

<p align="center" style="margin-top: 0; margin-bottom: 0">&nbsp;</p>

<p align="center" style="margin-top: 0; margin-bottom: 0">&nbsp;</p>

<hr color="#0099CC" size="1">

<p align="center" style="margin-top: 0; margin-bottom: 0">&nbsp;</p>

<p align="center" style="margin-top: 0; margin-bottom: 0"><b>
<font face="Trebuchet MS" color="#008000" size="6">MANAGEMENT AREA</font></b></p>
<p align="center" style="margin-top: 0; margin-bottom: 0">
<img border="0" src="../images/workstation_office_chair_spinning_md_wht.gif" width="120" height="90"></p>
<p align="center" style="margin-top: 0; margin-bottom: 0"><b>
<font face="Trebuchet MS" color="#000080">SCRIPT AFFILIASI CMS VER. 1.0</font></b></p>
<p align="center" style="margin-top: 0; margin-bottom: 0">&nbsp;</p>
<p align="center" style="margin-top: 0; margin-bottom: 0">
<img border="0" src="../images/img_12.gif" width="174" height="237"></p>
<p align="center" style="margin-top: 0; margin-bottom: 0">&nbsp;</p>
<hr color="#0099CC" size="1">
<p align="center" style="margin-top: 0; margin-bottom: 0">
<font face="Arial" style="font-size: 10pt" color="#999999">This Script Developed  
(c) By <a href="http://superautopilot.com" target=_blank>Superautopilot.com</font></p>

</body>

</html>