<?


require( "../config_sis.php" );
	if( !verifyAdmin() ) header( "Location: index.php" );
?>

<html>
<head>
<link rel="stylesheet" href="styles.css" type="text/css">
<title>Kirim Email Massal ke Member</title>
<script language="Javascript">
// validate form
function validate() {
	
	var error = "";
	
	// date check
	if(window.document.form1.rec_awal.value != "") {
		
		pattern = /^\d{4}-\d{2}-\d{2}$/
		if(!pattern.test(window.document.form1.rec_awal.value)) {
			error += "* Format Tanggal Mulai harus -> yyyy-mm-dd \n";
		}
	}
	
	// date check
	if(window.document.form1.rec_akhir.value != "") {
		
		pattern = /^\d{4}-\d{2}-\d{2}$/
		if(!pattern.test(window.document.form1.rec_akhir.value)) {
			error += "* Format Tanggal Sesudah harus -> yyyy-mm-dd \n";
		}
	}
	
	if(error) {
		error = "Silahkan betulkan sesuai perintah : \n\n" + error + "\n\n";
		alert(error);
		return false;
	} else {
		return true;
	}
}
</script>
</head>
<STYLE>BODY {
	SCROLLBAR-FACE-COLOR: #000000; SCROLLBAR-HIGHLIGHT-COLOR: #006699; SCROLLBAR-SHADOW-COLOR: #006699; SCROLLBAR-3DLIGHT-COLOR: #006699; SCROLLBAR-ARROW-COLOR: #ffffff ; SCROLLBAR-TRACK-COLOR: #C0C0C0; SCROLLBAR-DARKSHADOW-COLOR: #006699; SCROLLBAR-BASE-COLOR: #006699}
.lnk1:hover {
	COLOR: #0000fa; TEXT-DECORATION: none
}
.lnk:link {
	COLOR: #ffff00; TEXT-DECORATION: none
}

</STYLE>
<body id="text">

<div id="title2">
<p align="center" style="margin-top: 0; margin-bottom: 0"><font size="2">EMAIL KE MEMBER
</font> </p>
  <hr></div>

<form name="form1" method="post" action="admin_kirim_email_member1.php" onSubmit="return validate();">
<table id="text" style="width:100%;" height="420">
<tr style="background:#EEEEEE;">
      <td colspan="2" style="border-bottom: 1px solid #CCCCCC; background-color:#FFFFFF" height="37">
      <p align="justify" style="margin-top: 0; margin-bottom: 0">Karena beberapa 
      server saat ini memberlakukan PEMBATASAN terhadap Sistem <b>pengiriman 
      email massal</b>, maka lebih baik anda filter dalam proses pengimannya.</p>
      <p align="justify" style="margin-top: 0; margin-bottom: 0">Pengiriman email 
      massal Bisa anda lakukan <b>100</b> atau <b>150</b> atau <b>200</b> email 
      perjamnya, atau tergantung dari berapa banyak server memberi jatah email 
      massal&nbsp; perjamnya. Untuk mengetahui kuota email massal perjam lebih 
      baik anda kontak <b>admin server. </b>Filter pada script ini berdasarkan 
      tanggal.</td>
    </tr>
<tr style="background:#EEEEEE;">
      <td colspan="2" style="border-bottom: 1px solid #CCCCCC;" height="13">MEMILIH MEMBER</td>
    </tr>
<tr><td width="19%" height="13">Tanggal Mulai</td><td width="81%" height="13">
<input type="text" name="rec_awal" id="input" style="width:80px;" maxlength="10" size="20"> 
format tanggal -&gt; <font color="#CC3300">yyyy-mm-dd</font> (tahun-bulan-hari)</td></tr>
<tr><td height="16">Tanggal Sesudah</td><td height="16">
<input type="text" name="rec_akhir" id="input" style="width:80px;" maxlength="10" size="20"> 
format -&gt; <font color="#CC3300">yyyy-mm-dd</font> (tahun-bulan-hari)</td></tr>
<tr style="background:#EEEEEE;">
      <td colspan="2" style="border-bottom: 1px solid #CCCCCC; background-color:#FFFFFF" height="13">
      
      <p style="margin-top: 0; margin-bottom: 0">Kirim Email ke Member Paid / NoPaid / All ? 
      = 
<INPUT TYPE=RADIO NAME="status" VALUE="paid" CHECKED> <b>Paid </b>
<INPUT TYPE=RADIO NAME="status" VALUE="nopaid"> <b>NoPaid</b>   
<INPUT TYPE=RADIO NAME="status" VALUE="all"> <b>All Member</b></p>
      <p style="margin-top: 0; margin-bottom: 0">&nbsp;</p>
      <p style="margin-top: 0; margin-bottom: 0" align="left">
      Supaya email yang dikirim lebih &quot;<b>personal</b>&quot;, 
maka sapalah member anda</font></p>
<p align="left" style="margin-top: 0; margin-bottom: 0">
dengan menyebutkan namanya. </font>&nbsp;<u><b>Caranya :</b></u> Gunakan variable<b> %nama%</b> 
seperti contoh seperti dibawah</font></p>
      
      <BR> 
      </td>
    </tr>
<tr style="background:#EEEEEE;">
      <td colspan="2" style="border-bottom: 1px solid #CCCCCC;" height="13">PESAN</td>
    </tr>
<tr><td height="16">SUBJECT</td>
<td height="16">
<input type="text" name="subject" style="width:470px;" maxlength="250" id="input" size="20" value="Rekan %nama%, info penting buat anda"></td></tr>
<tr>
      <td valign="top" height="160">ISI PESAN</td>
<td height="160">
<textarea name="message" style="width:470px; height:200px;" id="input" rows="1" cols="15">Yth. Rekan : %nama% , Saya ada berita penting buat anda.</textarea></td></tr>
<tr><td height="18"></td><td height="18">
<input type="submit" id="button" value="Kirim email &gt;&gt;"></td></tr>
<tr style="background:#EEEEEE;">
<td colspan="2" style="border-bottom: 1px solid #CCCCCC; background-color:#FFFFFF" height="13"></td></tr>
<tr style="background:#EEEEEE;">
<td colspan="2" style="border-bottom: 1px solid #CCCCCC; background-color:#FFFFFF" height="13">
<font color="#CC3300"><i>Email anda terkirim pada member yang gabung diantara <b>
Tanggal Mulai</b> sampai <b>Tanggal Sesudah</b>.</i></font></td></tr>
<tr style="background:#EEEEEE;">
<td colspan="2" style="border-bottom: 1px solid #CCCCCC;" height="13">TAGS</td></tr>
<tr><td style="border-bottom: 1px solid #CCCCCC;" height="13">%nama%</td>
      <td style="border-bottom: 1px solid #CCCCCC;" height="13">Nama dari Member</td>
    </tr>
<tr><td style="border-bottom: 1px solid #CCCCCC;" height="13"></td>
      <td style="border-bottom: 1px solid #CCCCCC;" height="13"></td>
    </tr>
<tr>
      <td style="border-bottom: 1px solid #CCCCCC;" height="13"> </td>
      <td style="border-bottom: 1px solid #CCCCCC;" height="13"></td>
    </tr>
</table>
<input type="hidden" name="act" value="filter">
</form><p>


</body>
</html>