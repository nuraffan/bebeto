<?php

require( "../config_sis.php" );
if( !verifyAdmin() ) 
	{
	header( "Location: ../index.php" );
	return false;
	}
//if( !verifyAdmin() ) header( "Location: index.php" );
$user_admin = ltrim($_POST['user_admin']);
$passwd_admin = ltrim($_POST['passwd_admin']);
$nama_admin = ltrim($_POST['nama_admin']);
$email_admin = ltrim($_POST['email_admin']);
$alamat_admin = ltrim($_POST['alamat_admin']);
$telpon_admin = ltrim($_POST['telpon_admin']);
$website = ltrim($_POST['website']);
//$bonus_affiliasi = ltrim($bonus_sponsoring);
$bonus_cair = ltrim($_POST['bonus_cair']);
$bank_admin = ltrim($_POST['bank_admin']);
$cabang_bank_admin = ltrim($_POST['cabang_bank_admin']);
$rekening_admin = ltrim($_POST['rekening_admin']);
$nama_bisnis = ltrim($_POST['nama_bisnis']);


if( $user_admin == "" ) error( "Ooops . . . User Admin anda harus diisi!!!" );
if( $passwd_admin == "" ) error( "Ooops . . . Password belum diisi !!!" );
if( $nama_admin == "" ) error( "Ooops . . . Nama Harus Diisi !!!" );
if( $email_admin == "" ) error( "Ooops . . . Email anda harus diisi!!!" );
if( $alamat_admin == "" ) error( "Ooops . . . Alamat belum diisi !!!" );
if( $telpon_admin == "" ) error( "Ooops . . . Alamat Harus Diisi !!!" );
if( $website == "" ) error( "Ooops . . . Website anda harus diisi!!!" );
//if( $bonus_affiliasi == "" ) error( "Ooops . . . Bonus Affiliasi Harus Diisi !!!" );
if( $bonus_cair == "" ) error( "Ooops . . . Nilai Batas Pencairan Bonus Member Harus Diisi !!!" );
if( $bank_admin == "" ) error( "Ooops . . . Bank anda harus diisi!!!" );
if( $cabang_bank_admin == "" ) error( "Ooops . . . Cabang Bank belum diisi !!!" );
if( $rekening_admin == "" ) error( "Ooops . . . Rekening belum diisi !!!" );
if( $nama_bisnis == "" ) error( "Ooops . . . Nama Bisnis Harus Diisi !!!" );

dbConnect();
$nilai = mysql_query( "SELECT * FROM admin_affiliasi WHERE kode='$kode'" ) or error( mysql_error() );
$data = mysql_fetch_array( $nilai );
if( mysql_num_rows( $nilai ) != 1 ) error( "Ops ... ! Maaf Data administrator tidak ada !!!  " );
mysql_query( "UPDATE admin_affiliasi SET user_admin='$user_admin', passwd_admin='$passwd_admin', nama_admin='$nama_admin', email_admin='$email_admin',
alamat_admin='$alamat_admin', telpon_admin='$telpon_admin', website='$website', bonus_cair='$bonus_cair', bank_admin='$bank_admin', cabang_bank_admin='$cabang_bank_admin', rekening_admin='$rekening_admin', nama_bisnis='$nama_bisnis' WHERE kode='$kode' " ) or error( mysql_error() );

$subject_1 = "Laporan Upgrade Data Admin !!!";
$message_1 = "
===========================================================
Email ini terkirim karena anda melakukan editing data admin
	
=============== BERIKUT INI DATA-DATA ANDA : ==============  
Username Admin        : $user_admin
Password              : $passwd_admin
Nama Admin            : $nama_admin
email Admin           : $email_admin
Alamat Admin          : $alamat_admin
Telpon Admin          : $telpon_admin
Website               : $website
Harga Produk          : Rp. $data[harga_produk]
Bonus Affiliasi       : $data[bonus_affiliasi] %
Batas Pencairan Bonus : Rp. $bonus_cair
Bank Admin            : $bank_admin
Cabang Bank Admin     : $cabang_bank_admin
Rekening              : $rekening_admin
Nama Bisnis           : $nama_bisnis

   	
Demikian pemberitahuan ini Supaya disimpan.
        
    
 ";

$pesanBaru_1 = "----------------------->>$data[website]<<-----------------------------\n\n" . $message_1 . "\n\n";
sentMail( "$data[nama_bisnis] <$data[email_admin]>", $email_admin, $subject_1, $pesanBaru_1 );



displayHeader( "Admin > Editing Admin" );
echo "<p align=\"center\"><font size=\"2\">::: Editing Data Administrator Telah Sukses !!! :::</font></p>\n";
//echo "<p align=\"center\"><a href=\"admin_menu.php\"><b>Back to Admin</b></a></p>\n";


?>
