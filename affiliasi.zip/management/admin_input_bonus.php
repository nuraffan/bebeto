<?php 


    require( "../config_sis.php" );
    if( !verifyAdmin() ) 
	{
	header( "Location: ../index.php" );
	return false;
	}
    displayHeader( "Admin > Input Bonus" );
    $bayar_bonus = ltrim($_POST['bayar_bonus']);
	$user1 = ltrim($_POST['user1']);
	$sisa_bonus = ltrim($_POST['sisa_bonus']);
	if ($sisa_bonus <= 0) error("Ops ... ! MEMBER Tidak PUNYA BONUS ... Tidak perlu untuk di bayar");
	if ($bayar_bonus > $sisa_bonus) error("Ops ... ! Nilai yang ANDA INPUT LEBIH BESAR DARI BONUS MEMBER !!!");
	if ($bayar_bonus <= 0) error("Ops ... ! Dilarang Mengisi data LEBIH KECIL dari NOL");
	dbConnect();
	$result = mysql_query( "SELECT * FROM affiliasi where username='$user1'" ) or error( mysql_error() );
    $reseller = mysql_fetch_array( $result );
	$nilai = mysql_query( "SELECT * FROM admin_affiliasi WHERE kode='$kode'" ) or error( mysql_error() );
    $data = mysql_fetch_array( $nilai );
    if( mysql_num_rows( $nilai ) != 1 ) error( "Ops ... ! Maaf Data administrator tidak ada !!!  " );
    $status="nonaktif";
	$bayar = $reseller['bonus_terbayar'] + $bayar_bonus ;
    mysql_query( "UPDATE affiliasi SET bonus_terbayar='$bayar' WHERE username='$user1' " ) or error( mysql_error() );
 
    echo "<p align=\"center\"><font size=\"2\">::: Input data bonus sponsoring atas nama : <b>$reseller[nama]</b> Telah Sukses !!! :::</font></p>\n";
    echo "<p align=\"center\"><a href=\"admin_bayar_bonus3.php?user=$user1\"><b>Kembali</b></a></p>\n";
	

?>