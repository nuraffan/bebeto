<?php 

// #-------------------------- Script Indo Affiliate 2008 Ver 1.0 ---------------#
// #------------------- Copyright � 2008 Ali Rasbany - Yogyakarta  --------------#
// #------------------------ http://www.superautopilot.com  ---------------------#
// #----------------------- Protected By Indonesian Law  ------------------------#

require( "../config_sis.php" );
if( !verifyAdmin() ) 
	{
	header( "Location: ../index.php" );
	return false;
	}
//if( !verifyAdmin() ) header( "Location: index.php" );
$nama = ltrim($_POST['nama']);
$kota = ltrim($_POST['kota']);
$email = ltrim($_POST['email']);
$judul = ltrim($_POST['judul']);
$isi = ltrim($_POST['isi']);

if( $nama == "" ) error( "Ooops . . . Nama harus diisi!!!" );
if( $kota == "" ) error( "Ooops . . . Kota Harus diisi !!!" );
if( $email == "" ) error( "Ooops . . . Email Harus diisi !!!" );
if( $judul == "" ) error( "Ooops . . . Judul Harus diisi !!!" );
if( $isi == "" ) error( "Ooops . . . Isi Harus diisi !!!" );

dbConnect();
mysql_query( "INSERT INTO testimonial ( nama, kota, email, judul, isi )
Values ('$nama','$kota','$email','$judul','$isi')") or error( mysql_error() );

header("Location:admin_testimonial.php") ;

?>