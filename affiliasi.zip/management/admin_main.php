<?
require( "../config_sis.php" );
if( !verifyAdmin() ) 
	{
	header( "Location: index.php" );
	return false;
	}
?>

<html>
<title>:: Management Area ::</title>
<frameset cols="200,*" frameborder=0 border=0 framespacing=0>
<frame src="admin_menu.php" name="menu" scrolling="no">
<frame src="admin_pesan.php" name="main">
</frameset>
</html>