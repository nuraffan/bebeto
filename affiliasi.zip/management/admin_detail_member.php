<?php

    require( "../config_sis.php" );
	if( !verifyAdmin() ) 
	{
	header( "Location: index.php" );
	return false;
	}

    displayHeader( "Admin > Detail Member" );

    dbConnect();
	$result = mysql_query( "SELECT * FROM customer where email='$_GET[email]'" ) or error( mysql_error() );
    $reseller = mysql_fetch_array( $result );
     if( mysql_num_rows( $result ) != 1 ) error( "Data yang anda cari tidak ada dalam database " );
        echo "<p style=\"margin-top: 0; margin-bottom: 0\" align=\"center\"><font size=\"2\">Detail Member Nama = <b>$reseller[nama]</b></font></p>\n";
	    echo "<div align=\"center\">\n";
	    echo "  <center>\n";
	    echo "  <table border=\"0\" cellspacing=\"0\" width=\"500\" cellpadding=\"5\"><font size=\"1\" face=\"Tahoma\" >\n";
	    echo "    <tr class=\"frame\">\n";
	    echo "      <td width=\"30%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#FFFFFF\"><b></b></font></td>\n";
	    echo "      <td width=\"70%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#FFFFFF\"><b>Detail Data Member</b></font></td>\n";
	    echo "    </tr>\n";
  	    $bgColor = "#E6E6E6";

       	echo "    <tr>\n";
        echo "      <td width=\"30%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">Email</td>\n";
	    echo "      <td width=\"70%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">: $reseller[email]</td>\n";
	    echo "    </tr>\n";
       
       	echo "    <tr>\n";
        echo "      <td width=\"30%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">Password</td>\n";
	    echo "      <td width=\"70%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">: $reseller[passwd]</td>\n";
	    echo "    </tr>\n";
		
		echo "    <tr>\n";
        echo "      <td width=\"30%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">Nama</td>\n";
	    echo "      <td width=\"70%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">: $reseller[nama]</td>\n";
	    echo "    </tr>\n";
		 
		echo "    <tr>\n";
        echo "      <td width=\"30%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">Alamat</td>\n";
	    echo "      <td width=\"70%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">: $reseller[alamat]</td>\n";
	    echo "    </tr>\n";
		 
		echo "    <tr>\n";
        echo "      <td width=\"30%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">Telepon</td>\n";
	    echo "      <td width=\"70%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">: $reseller[telpon]</td>\n";
	    echo "    </tr>\n"; 
		 
		echo "    <tr>\n";
        echo "      <td width=\"30%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">Kota</td>\n";
	    echo "      <td width=\"70%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">: $reseller[kota]</td>\n";
	    echo "    </tr>\n";
		$RUPIAH_ADMIN = rupiah($reseller['rupiah_pembelian']);
		echo "    <tr>\n";
        echo "      <td width=\"30%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">Transfer</td>\n";
	    echo "      <td width=\"70%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">: $RUPIAH_ADMIN</td>\n";
	    echo "    </tr>\n"; 
						
		echo "    <tr>\n";
        echo "      <td width=\"30%\" height=\"25\" align=\"left\" ><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">Nama Bank</td>\n";
	    echo "      <td width=\"70%\" height=\"25\" align=\"left\" ><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">: $reseller[nama_bank]</td>\n";
	    echo "    </tr>\n";
		
		echo "    <tr>\n";
        echo "      <td width=\"30%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">Rekening</td>\n";
	    echo "      <td width=\"70%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">: $reseller[rekening]</td>\n";
	    echo "    </tr>\n";
		
		
		echo "    <tr>\n";
        echo "      <td width=\"30%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">Cabang Bank</td>\n";
	    echo "      <td width=\"70%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">: $reseller[cabang_bank]</td>\n";
	    echo "    </tr>\n";
		
		
		echo "    <tr>\n";
        echo "      <td width=\"30%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">Tanggal Transfer</td>\n";
	    echo "      <td width=\"70%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">: $reseller[tanggal_transfer]</td>\n";
	    echo "    </tr>\n";
		
		echo "    <tr>\n";
        echo "      <td width=\"30%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">Username Sponsor </td>\n";
	    echo "      <td width=\"70%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">: $reseller[username_sponsor]</td>\n";
	    echo "    </tr>\n";
		
				
		echo "    <tr>\n";
        echo "      <td width=\"30%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">Tanggal Join</td>\n";
	    echo "      <td width=\"70%\" height=\"25\" align=\"left\" ><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">: $reseller[tanggal_join]</td>\n";
	    echo "    </tr>\n";
		
		echo "    <tr>\n";
        echo "      <td width=\"30%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">IP Address Saat Join</td>\n";
	    echo "      <td width=\"70%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">: $reseller[ip_add]</td>\n";
	    echo "    </tr>\n";
		
		echo "    <tr>\n";
        echo "      <td width=\"30%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">Status Bayar</td>\n";
	    echo "      <td width=\"70%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">: $reseller[paid]</td>\n";
	    echo "    </tr>\n";
		
  echo "    <tr>\n";
        echo "      <td width=\"30%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">Status</td>\n";
	    echo "      <td width=\"70%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">: $reseller[stat]</td>\n";
	    echo "    </tr>\n";
		 
			  
 	    echo "    <tr>\n";
        echo "      <td width=\"100%\" height=\"1\" bgcolor=\"#808080\" colspan=\"5\"></td>\n";
 	    echo "    </td>\n";
 	    echo "  </table>\n";
 	    echo " </center>\n";
	    echo "</div>\n";

        //echo "<p align=\"center\"><font size=\"2\"><a href=\"admin_menu.php\"><b>Back to Admin</b></a></p>\n";
	
?>
