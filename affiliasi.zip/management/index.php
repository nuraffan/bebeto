<?php 

	require( "../config_sis.php" );
	error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
	if ($_GET['action'])
	{
		if( $_GET['action'] == "login" )
		{
		
            $admin_Name = trim($_POST['admin_Name']);
            $admin_Passwd = trim($_POST['admin_Passwd']);
			dbConnect();
            $nilai = mysql_query( "SELECT user_admin FROM admin_affiliasi WHERE user_admin='$admin_Name'" ) or error( mysql_error() );
            if( mysql_num_rows($nilai) != 1 ) error( "Maaf, Username Admin ini tidak ada dalam database kami" );
            $nilai = mysql_query( "SELECT user_admin FROM admin_affiliasi WHERE user_admin='$admin_Name' AND passwd_admin LIKE BINARY '$admin_Passwd'" ) or error( mysqli_error() );
            if( mysql_num_rows( $nilai ) != 1 ) error( "Maaf, Password Anda Salah !!! " );
			else
            {
              $_SESSION[admin_Name]=$admin_Name;
              $_SESSION[admin_Passwd]=$admin_Passwd;
              header( "Location: admin_main.php" );
            }
         }
         if( $_GET[action] == "logout" )
         {
            session_destroy();
            unset($_SESSION[admin_Name]);
            unset($_SESSION[admin_Passwd]);
            displayHeader( "Admin Logout" );
            echo "<p align=\"center\"><font size=\"4\">Anda Telah Logout Dengan Sukses !</font></p>\n";
            echo "<p align=\"center\"><a href=\"../index.php\"><b>Halaman Utama</b></a></p>\n";
         }

                if( $_GET[action] == "lupa" )
		{
                        $mail = trim( $_POST['mail'] );
                        if ( $mail == "" ) error( "Silahkan Isi email dengan benar !!!" );
                        if ( !eregi( "^[0-9a-z]([-_.]?[0-9a-z])*@[0-9a-z]([-.]?[0-9a-z])*\\.[a-z]{2,3}$", $mail ) ) error( "Oops .. data Email anda Invalid alias tidak sah !!!" );
                        dbConnect();
                        $nilai = mysqli_query( "SELECT * FROM admin_affiliasi WHERE kode='$kode'" ) or error( mysqli_error() );
                        $data = mysqli_fetch_array( $nilai );
                        $result = mysqli_query( "SELECT email_admin FROM admin_affiliasi WHERE email_admin='$mail'" ) or error( mysqli_error() );
                        if( mysqli_num_rows( $result ) != 1 ) error( "Maaf, Email anda tidak terdaftar dalam database, atau mungkin anda lupa" );
                        else
                           {
                           dbConnect();
	                   $result = mysqli_query( "SELECT * FROM admin_affiliasi where email_admin='$mail'" ) or error( mysqli_error() );
                           $manage = mysqli_fetch_array( $result );

// --- PERHATIAN !!! Untuk mencegah error Jangan Ganti Variabel yang berawalan tanda "$"

$subject_1 = ">> Pengiriman Password Admin !!! ";
$message_1 = "
Hallo $manage[nama_admin] Berikut ini password anda

________________________________________________
UserAdmin  : $manage[user_admin]
Password   : $manage[passwd_admin]

simpan baik-baik jangan sampai lupa Ok, ;
________________________________________________
";
$pesanBaru_1 = "----------------------->>$data[website]<<-----------------------------\n\n" . $message_1 . "\n\n";
sentMail( "$data[nama_bisnis] <$data[email_admin]>", $mail, $subject_1, $pesanBaru_1 );

                        displayHeader( "Admin Lupa Password" );
                        echo "<p align=\"center\"><font size=\"4\">Data Password sudah terkirim ke email : <b>$mail</b> !</font></p>\n";
			echo "<p align=\"center\"><a href=\"../index.php\"><b>Home</b></a></p>\n";
            }
		}

	}
	else
	{
		if( verifyAdmin() ) header( "Location: admin_main.php" );
        echo "<p align=\"center\"><img src=\"../images/admine.gif\"  border=\"0\" ></a></p>\n";
		displayHeader( "Administrator Validasi" );
		echo "<p align=\"center\"><b><font face=\"Tahoma\" size=\"4\">:: Administrator Validasi ::</font></b></p>\n";
		echo "<div align=\"center\">\n";
		echo "  <center>\n";
		echo "  <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\n";
		echo "  <form method=\"post\" action=\"$PHP_SELF?action=login\">\n";
		echo "    <tr>\n";
		echo "      <td width=\"80\" height=\"25\"><b>Username</b></td>\n";
		echo "      <td width=\"160\" height=\"25\"><input type=\"text\" name=\"admin_Name\" size=\"20\" maxlength=\"50\"></td>\n";
		echo "    </tr>\n";
		echo "    <tr>\n";
		echo "      <td width=\"80\" height=\"25\"><b>Password</b></td>\n";
		echo "      <td width=\"160\" height=\"25\"><input type=\"password\" name=\"admin_Passwd\" size=\"20\" maxlength=\"12\"></td>\n";
		echo "    </tr>\n";
		echo "    <tr>\n";
		echo "      <td width=\"8\" height=\"25\"></td>\n";
		echo "      <td width=\"160\" height=\"25\"><input type=\"submit\" value=\"  Login Admin >>\"></td>\n";
		echo "    </tr>\n";
		echo "  </form>\n";
		echo "  </table>\n";
		echo "  </center>\n";
  	    echo "</div>\n";
		echo "<p style=\"margin-top: 0; margin-bottom: 0 \">&nbsp;</p>\n";
        echo "<p align=\"center\" style=\"margin-top: 0; margin-bottom: 0\"> \n";
		echo "<font face=\"Verdana\" size=\"2\"><b>Lupa Password Anda.?</b></font></p>\n";
        echo "<p align=\"center\" style=\"margin-top: 0; margin-bottom: 0\">\n";
        echo "<font face=\"Verdana\" size=\"2\"><b>Ambil dengan email admin</b></font></p> \n";
        echo "<form method=\"POST\" action=\"$PHP_SELF?action=lupa\"> \n";
        echo "<p align=\"center\" style=\"margin-top: 0; margin-bottom: 0\">\n";
        echo "<input type=\"text\" name=\"mail\" size=\"20\"></p> \n";
        echo "<p align=\"center\" style=\"margin-top: 0; margin-bottom: 0\">\n";
        echo "<input type=\"submit\" value=\"Get Password >>\" name=\"B1\"></p> \n";
        echo "</form> \n";

		echo "<p align=\"center\"><a href=\"javascript:history.back();\"><b>Kembali</b></a> | <a href=\"../index.php\"><b>Halaman Depan</b></a></p>\n";
	}

      
?>