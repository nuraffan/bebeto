<?

	require( "../config_sis.php" );
        if( !verifyAdmin() ) 
	     {
	     header( "Location: ../index.php" );
	     return false;
	     }
        if ($_GET[email])
	    {
        dbConnect();
	    mysql_query( "DELETE FROM customer WHERE email='$_GET[email]' " ) or error( mysql_error() );

        displayHeader( "Admin > Hapus Member" );
        echo "<p align=\"center\"><font size=\"2\">::: Menghapus Member Dengan Email : <b>$_GET[email]</b> Telah Sukses !!! :::</font></p>\n";
       // echo "<p align=\"center\"><a href=\"admin_menu.php\"><b>Back to Admin</b></a></p>\n";
       

        }
	
?>
