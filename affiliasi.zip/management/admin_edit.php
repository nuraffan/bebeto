<?php

    require( "../config_sis.php" );
   if( !verifyAdmin() ) 
	{
	header( "Location: ../index.php" );
	return false;
	}
   //if( !verifyAdmin() ) header( "Location: index.php" );
    displayHeader( "Admin > Editing Admin" );
    dbConnect();
	$nilai = mysql_query( "SELECT * FROM admin_affiliasi WHERE kode='$kode'" ) or error( mysql_error() );
    $data = mysql_fetch_array( $nilai );
    if( mysql_num_rows( $nilai ) != 1 ) error( "Ops ... ! Maaf Data administrator tidak ada" );
	
        echo "<p style=\"margin-top: 0; margin-bottom: 0\" align=\"center\"><font size=\"4\"><b>Editing Data Administrator</b></font></p>\n";
	    echo "<div align=\"center\">\n";
		echo "  <center>\n";
		
	    echo "  <table border=\"0\" cellspacing=\"0\" width=\"675\" cellpadding=\"5\"><font size=\"1\" face=\"Tahoma\" >\n";
	    echo "    <tr class=\"frame\">\n";
		echo "      <form name=\"Klikabadi\" action=\"admin_edit2.php\" method=\"post\">\n";
	    echo "      <td width=\"50%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#FFFFFF\"><b></b></font></td>\n";
	    echo "      <td width=\"50%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#FFFFFF\"><b></b></font></td>\n";
	    echo "    </tr>\n";
  	    $bgColor = "#E6E6E6";

       	echo "    <tr>\n";
        echo "      <td width=\"50%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">Admin</td>\n";
	    echo "      <td width=\"50%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">: <input  name=\"user_admin\" value=\"$data[user_admin]\" size=\"20\"></td>\n";
	    echo "    </tr>\n";
       
       	echo "    <tr>\n";
        echo "      <td width=\"50%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">Password</td>\n";
	    echo "      <td width=\"50%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">: <input  name=\"passwd_admin\" value=\"$data[passwd_admin]\" size=\"20\"></td>\n";
	    echo "    </tr>\n";
		
		echo "    <tr>\n";
        echo "      <td width=\"50%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">Nama Administrator</td>\n";
	    echo "      <td width=\"50%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">: <input  name=\"nama_admin\" value=\"$data[nama_admin]\" size=\"20\"></td>\n";
	    echo "    </tr>\n";
		 
		echo "    <tr>\n";
        echo "      <td width=\"50%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">Email Administrator</td>\n";
	    echo "      <td width=\"50%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">: <input  name=\"email_admin\" value=\"$data[email_admin]\" size=\"25\"></td>\n";
	    echo "    </tr>\n";
		 
		echo "    <tr>\n";
        echo "      <td width=\"50%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">Alamat Administrator</td>\n";
	    echo "      <td width=\"50%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">: <input  name=\"alamat_admin\" value=\"$data[alamat_admin]\" size=\"35\"</b></td>\n";
	    echo "    </tr>\n"; 
		 
		echo "    <tr>\n";
        echo "      <td width=\"50%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">Telpon Administrator</td>\n";
	    echo "      <td width=\"50%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">: <input  name=\"telpon_admin\" value=\"$data[telpon_admin]\" size=\"20\"></td>\n";
	    echo "    </tr>\n";
		
		echo "    <tr>\n";
        echo "      <td width=\"50%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">Nama Domain Website (tulis dengan lengkap)</td>\n";
	    echo "      <td width=\"50%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">: <input  name=\"website\" value=\"$data[website]\" size=\"35\"></b></td>\n";
	    echo "    </tr>\n"; 
		
         echo "    <tr>\n";
        echo "      <td width=\"50%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\"><b>Harga Produk</b> (maaf tidak bisa di edit karena akan pengaruh pada data perhitungan bonus)</td>\n";
	    echo "      <td width=\"50%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">: <b>Rp. $data[harga_produk]</b> <size=\"20\"></td>\n";
	    echo "    </tr>\n";
  
  
		echo "    <tr>\n";
        echo "      <td width=\"60%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\"><b>Bonus Affiliasi</b> (maaf tidak bisa di edit karena akan pengaruh pada data perhitungan bonus)</td>\n";
	    echo "      <td width=\"40%\" height=\"25\" align=\"left\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">: <b>$data[bonus_affiliasi] %</b><size=\"20\"></td>\n";
	    echo "    </tr>\n";
		
		
		echo "    <tr>\n";
        echo "      <td width=\"60%\" height=\"25\" align=\"left\" ><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">Batas Minimal Pencairan Bonus <i>(Misal <b>Rp 10.000</b> Tulis : <b>10000</b>)</i> </td>\n";
	    echo "      <td width=\"40%\" height=\"25\" align=\"left\" ><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">: <input  name=\"bonus_cair\" value=\"$data[bonus_cair]\" size=\"20\"></td>\n";
	    echo "    </tr>\n";
		
		echo "    <tr>\n";
        echo "      <td width=\"50%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\" ><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">Nama Bank Administrator</td>\n";
	    echo "      <td width=\"50%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\" ><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">: <input  name=\"bank_admin\" value=\"$data[bank_admin]\" size=\"35\"></td>\n";
	    echo "    </tr>\n";
		
		echo "    <tr>\n";
        echo "      <td width=\"50%\" height=\"25\" align=\"left\" ><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">Cabang Bank Administrator</td>\n";
	    echo "      <td width=\"50%\" height=\"25\" align=\"left\" ><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">: <input  name=\"cabang_bank_admin\" value=\"$data[cabang_bank_admin]\" size=\"35\"></td>\n";
	    echo "    </tr>\n";
		
		echo "    <tr>\n";
        echo "      <td width=\"50%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">Nomor Rekening </td>\n";
	    echo "      <td width=\"50%\" height=\"25\" align=\"left\" bgcolor=\"$bgColor\"><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">: <input  name=\"rekening_admin\" value=\"$data[rekening_admin]\" size=\"20\"></td>\n";
	    echo "    </tr>\n";
		
		echo "    <tr>\n";
        echo "      <td width=\"50%\" height=\"25\" align=\"left\" ><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">Nama / Headline Bisnis anda</td>\n";
	    echo "      <td width=\"50%\" height=\"25\" align=\"left\" ><font face=\"verdana\" style=\"font-size: 8pt\" color=\"#000080\">: <input  name=\"nama_bisnis\" value=\"$data[nama_bisnis]\" size=\"20\"></td>\n";
	    echo "    </tr>\n";
		
		
 	    echo "    <tr>\n";
		
        echo "      <td width=\"100%\" height=\"1\" bgcolor=\"#808080\" colspan=\"5\"></td>\n";
 	    echo "    </td>\n";
 	    echo "  </table>\n";
		echo "    <p align=\"center\"><font face=\"Verdana\"><input type=\"submit\" value=\"EDIT DATA ADMIN\" name=\"Submit\"> </font>\n";
		echo "  </form>\n";
 	    echo " </center>\n";
	    echo "</div>\n";

       // echo "<p align=\"center\"><font size=\"2\"><a href=\"admin_menu.php\"><b>Back to Admin</b></a></p>\n";
	
?>
