<?php 

	require( "../config_sis.php" );
	if( !verifyAdmin() ) 
	{
	header( "Location: index.php" );
	return false;
	}
    if ($_GET[user])
	{
    dbConnect();
	$result = mysql_query( "SELECT * FROM affiliasi where username='$_GET[user]'" ) or error( mysql_error() );
    $reseller = mysql_fetch_array( $result );
	$nilai = mysql_query( "SELECT * FROM admin_affiliasi WHERE kode='$kode'" ) or error( mysql_error() );
    $data = mysql_fetch_array( $nilai );
    if( mysql_num_rows( $nilai ) != 1 ) error( "Ops ... ! Maaf Data administrator tidak ada !!!  " );
    $status="nonaktif";
    mysql_query( "UPDATE affiliasi SET stat1='$status' WHERE username='$_GET[user]' " ) or error( mysql_error() );
        
        require ("../email/email_blokir_affiliasi.php");        
  
        
        displayHeader( "Admin > Member List" );
        echo "<p align=\"center\"><font size=\"2\">::: Pemblokiran Member Affiliasi Dengan Username : <b>$_GET[user]</b> Telah Sukses !!! :::</font></p>\n";
        //echo "<p align=\"center\"><a href=\"admin_menu.php\"><b>Back to Admin</b></a></p>\n";

        }
	

?>