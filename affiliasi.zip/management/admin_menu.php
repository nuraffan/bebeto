<?
require( "../config_sis.php" );
if( !verifyAdmin() ) 
	{
	header( "Location: index.php" );
	return false;
	}
?>

<html>
<head>
<link rel="stylesheet" href="styles.css" type="text/css">
<style type="text/css">

</style>
</head>

<title>Admin Area</title>
<body style="margin:5px; background:#000000;">
<p>

<table id="title" style="color:#FFFFFF;" height="100">
<tr>
    <td style="padding:2px; padding-left:5px; width:158px;" height="4"> &nbsp;&nbsp;&nbsp;&nbsp;
    <font size="2">:: ADMIN MENU ::</font></td>
  </tr>
<tr>
    <td height="6"></td>
  </tr>
<tr>
    <td height="6">
    <p align="left">:: MEMBER MANAGEMENT</td>
  </tr>
<tr><td height="12">- <a target="main" href="admin_list_all_member.php">
<font color="#FFCC33">Lihat&nbsp; Semua Member</font></a></td></tr>
<tr><td height="12">- <a target="main" href="admin_aktif_member.php">
<font color="#FFCC33">Aktifkan Member</font></a></td></tr>
<tr><td height="12">- <a target="main" href="admin_blokir_member.php">
<font color="#FFCC33">Memblokir Member</font></a></td></tr>
<tr><td height="12">- <a target="main" href="admin_aktif_member_lagi.php">
<font color="#FFCC33">Aktifkan dari BLOKIR</font></a></td></tr>
<tr><td height="10">- <a target="main" href="admin_kirim_email_member.php">
<font color="#FFCC33">Kirim Email ke Member</font></a></td></tr>
<tr><td height="12">- <a target="main" href="admin_search_member.php">
<font color="#FFCC33">Cari Member</font></a></td></tr>
<tr><td height="12"></td></tr>
<tr><td height="12">
    <p align="left">:: AFFILIASI MANAGEMENT</td>
<tr><td height="12">- <a target="main" href="admin_list_all_affiliasi.php">
<font color="#FFCC33">Lihat Semua Affiliasi</font></a></td></tr>
<tr><td height="12">- <a target="main" href="admin_blokir_affiliasi.php">
<font color="#FFCC33">Memblokir Affiliasi</font></a></td></tr>
<tr><td height="12">- <a target="main" href="admin_aktif_affiliasi_lagi.php">
<font color="#FFCC33">Mengaktifkan Affiliasi</font></a></td></tr>
<tr><td height="12">- <a target="main" href="admin_kirim_email_affiliasi.php">
<font color="#FFCC33">Kirim Email ke Affiliasi</font></a></td></tr>
<tr><td height="12">- <a target="main" href="admin_search_affiliasi.php">
<font color="#FFCC33">Cari Affiliasi</font></a></td></tr>
<tr><td height="12">- <a target="main" href="admin_bayar_bonus.php">
<font color="#FFCC33">Pembayaran Bonus</font></a></td></tr>
<tr><td height="12"></td></tr>
<tr><td height="12">
    <p align="left">:: ADMIN MANAGEMENT</td>
<tr><td height="12">- <a target="main" href="admin_edit.php">
<font color="#FFCC33">Edit Data Admin</font></a></td></tr>
<tr><td height="12">- <a target="main" href="admin_statistik.php">
<font color="#FFCC33">Statistik Kunjungan Web</font></a></td></tr>
<tr><td height="12">- <a target="main" href="admin_news.php">
<font color="#FFCC33">Input/Delete Berita</font></a></td></tr>
<tr><td height="12">- <a target="main" href="admin_testimonial.php">
<font color="#FFCC33">Input/Delete Testimonial</font></a></td></tr>
<tr><td height="12"></td></tr>

<tr><td height="12"></td></tr>
<p align="left">- <a target="main" href="admin_backup.php">
<font color="#FFCC33"><b>Backup Database</b></font></a> - </td></tr>
<tr><td height="12"></td></tr>
<tr><td height="12">
<p align="center">::
<a class="menu" title="LOg Out Management" target="_top" href="index.php?action=logout"><b>LOG - OFF</b></a> 
::</td></tr>
</table>

</body>
</html>