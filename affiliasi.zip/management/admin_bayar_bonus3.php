<?php

require( "../config_sis.php" );
    if( !verifyAdmin() ) 
	{
	header( "Location: ../index.php" );
	return false;
	}
displayHeader( "Admin > Bayar Affiliasi" );
dbConnect();
$result = mysql_query( "SELECT * FROM affiliasi where username='$_GET[user]'" ) or error( mysql_error() );
$datamember = mysql_fetch_array( $result );

$nilai = mysql_query( "SELECT * FROM admin_affiliasi WHERE kode='$kode'" ) or error( mysql_error() );
$data = mysql_fetch_array( $nilai );
$status = "aktif";
$paid="paid";
$result1 = mysql_query( "SELECT * FROM customer where username_sponsor='$_GET[user]' AND paid='$paid' " ) or error( mysql_error() );
$jumlah_member = mysql_num_rows( $result1 );

//$test = mysql_query("SELECT * from memberarisan where username='$session_username'")or error( mysql_error() );
//$datamember = mysql_fetch_array( $test );
$AFFILIASI = $data['harga_produk'] * $data['bonus_affiliasi'] / 100;
$rupiah_affiliasi = rupiah($AFFILIASI);

//$rupiah_affiliasi = rupiah($data[bonus_affiliasi]);
$rupiah_bonus_cair = rupiah($data['bonus_cair']);

$total_bonus = $jumlah_member * $AFFILIASI;
$rupiah_total_bonus = rupiah($total_bonus);

$bonus_terbayar = $datamember['bonus_terbayar'] ;
$sisa_bayar_total = $total_bonus - $bonus_terbayar ;
$rupiah_bonus_terbayar = rupiah($bonus_terbayar);
$rupiah_sisa_bayar_total = rupiah($sisa_bayar_total);



?>
<html>

<head>
    <link href="../style.css" type="text/css" rel="stylesheet">
    <style type="text/css">

    
<!--
.style1 {color: #FFFFFF}
.style2 {font-size: 10px}
-->
      </style>
    <link href="../style.css" type="text/css" rel="stylesheet">
    <style type="text/css">

<!--
.style1 {color: #FFFFFF}
-->
    </style>
    
<meta http-equiv="Content-Language" content="en-us">
<title>:: Admin Area :: Script Powered By klikabadi.com </title>
<META content=Noerhadi name=Author>
<META 
content=" Pasang iklan dan cari uang penghasilan abadi tiap hari dari Internet dengan ebook gratis atau free." 
name=Keywords>
<META 
content="tutorial situs dalam bahasa indonesia, membahas teknik-teknik mencari uang secara online melalui internet." 
name=Description>
<META content="index, follow" name=robots>
            
           
<style fprolloverstyle>A:hover {color: #FF0000; font-weight: bold}
    </style>

</head>

<body>

<noscript></noscript>
<table cellSpacing="0" cellPadding="0" width="570" align="center" border="0" name="contentandmenu">
  <tr>
    <td vAlign="top" bgColor="#ffffff" width="398">
    <p align="center" style="margin-top: 0; margin-bottom: 0"><div align="center">
      <center>
      <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="572" id="AutoNumber2">
        <tr>
          <td width="572">
          <p style="margin-top: 0; margin-bottom: 0" align="center">
          <span lang="id"><font size="3" color="#FF0000"><b>HALAMAN PEMBAYARAN</b></font></span></p>
          <p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;
          </p>
          <p style="margin-top: 0; margin-bottom: 0" align="center">
          <font color="#008080"><span lang="id"><b>Data member :</b></span></font></p>
          <div align="center">
            <center>
            <table border="1" cellpadding="4" cellspacing="0" style="border-collapse: collapse" bordercolor="#FFFFFF" width="500" id="AutoNumber6">
              <tr>
                <td width="194" bgcolor="#339966"><font color="#FFFFFF">
                <span style="font-size: 8pt; font-weight: 700" lang="id">
                Username</span></font></td>
                <td width="295" bgcolor="#339966"><font color="#FFFF00">
                <span style="font-size: 8pt; font-weight: 700" lang="id"><?php echo"$_GET[user]"   ?></span></font>&nbsp;</td>
              </tr>
              <tr>
                <td width="194" bgcolor="#00CC66"><font color="#FFFFFF">
                <span style="font-size: 8pt; font-weight: 700" lang="id">Nama</span></font></td>
                <td width="295" bgcolor="#00CC66"><font color="#FFFF00">
                <span style="font-size: 8pt; font-weight: 700" lang="id"><?php echo"{$datamember['nama']}"   ?></span></font>&nbsp;</td>
              </tr>
              <tr>
                <td width="194" bgcolor="#339966"><font color="#FFFFFF">
                <span style="font-size: 8pt; font-weight: 700" lang="id">Alamat</span></font></td>
                <td width="295" bgcolor="#339966"><font color="#FFFF00">
                <span style="font-size: 8pt; font-weight: 700" lang="id"><?php echo"{$datamember['alamat']}"   ?></span></font>&nbsp;</td>
              </tr>
              <tr>
                <td width="194" bgcolor="#00CC66"><font color="#FFFFFF">
                <span style="font-size: 8pt; font-weight: 700" lang="id">Kota</span></font></td>
                <td width="295" bgcolor="#00CC66"><font color="#FFFF00">
                <span style="font-size: 8pt; font-weight: 700" lang="id"><?php echo"{$datamember['kota']}"   ?></span></font>&nbsp;</td>
              </tr>
              <tr>
                <td width="194" bgcolor="#339966"><font color="#FFFFFF">
                <span style="font-size: 8pt; font-weight: 700" lang="id">telpon</span></font></td>
                <td width="295" bgcolor="#339966"><font color="#FFFF00">
                <span style="font-size: 8pt; font-weight: 700" lang="id"><?php echo"{$datamember['telpon']}"   ?></span></font>&nbsp;</td>
              </tr>
              <tr>
                        <td width="194" bgcolor="#00CC66"><font color="#FFFFFF"> 
                          <span style="font-size: 8pt; font-weight: 700" lang="id">Email</span></font></td>
                <td width="295" bgcolor="#00CC66"><font color="#FFFF00">
                <span style="font-size: 8pt; font-weight: 700" lang="id"><?php echo"{$datamember['email']}"   ?></span></font>&nbsp;</td>
              </tr>
            </table>
            </center>
          </div>
          <p style="line-height: 100%; margin-top: 0; margin-bottom: 0">&nbsp;</p>
            <p style="line-height: 100%; margin-top: 0; margin-bottom: 0" align="center">&nbsp; &nbsp;
            </p>
            <hr color="#CCCCCC" width="500" size="1">
            <p style="line-height: 100%; margin-top: 0; margin-bottom: 0" align="center">&nbsp;</p>
            <p style="line-height: 150%; margin-top: 0; margin-bottom: 0" align="center">
            <b><font color="#006699"><span lang="id">STATUS BONUS&nbsp;  </span></font></b></p>
            <div align="center">
              <center>
              <table border="1" cellpadding="2" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="500" id="AutoNumber8">
                <tr>
                  <td align="center" width="88" height="14" bgcolor="#008080">
                  <font color="#FFFFFF" face="Verdana">
                  <span style="font-size: 8pt; font-weight: 700" lang="id">Hasil 
                  Rekrut</span></font></td>
                  <td align="center" width="122" height="14" bgcolor="#008080">
                  <font color="#FFFFFF" face="Verdana">
                  <span style="font-size: 8pt; font-weight: 700" lang="id">Bonus </span></font>
                  <span style="font-weight: 700">
                  <font face="Verdana" style="font-size: 8pt" color="#FFFFFF">
                  Affiliasi</font></span></td>
                  <td align="center" width="172" height="14" bgcolor="#008080">
                  <font color="#FFFFFF" face="Verdana">
                  <span style="font-size: 8pt; font-weight: 700" lang="id">
                  Perhitungan</span></font></td>
                  <td align="center" width="113" height="14" bgcolor="#008080">
                  <p style="line-height: 100%">
                  <font color="#FFFFFF" face="Verdana">
                  <span style="font-size: 8pt; font-weight: 700" lang="id">Total 
                  Bonus </span>
                  <span style="font-size: 8pt; font-weight: 700">Affiliasi  </span></font></td>
                </tr>
                <tr>
                  <td align="center" width="88" height="1" bgcolor="#009999">
                  <font color="#FFFFFF">
                  <span style="font-size: 8pt" lang="id"><?php echo"$jumlah_member" ?></span></font></td>
                  <td align="center" width="122" height="1" bgcolor="#009999">
                  <span lang="id"><font color="#FFFFFF" face="Verdana">
                  <span style="font-size: 8pt">@ <?php echo" $rupiah_affiliasi" ?></span></font></span></td>
                  <td align="center" width="172" height="1" bgcolor="#009999">
                  <font color="#FFFFFF">
                  <span style="font-size: 8pt" lang="id"><?php echo "$jumlah_member" ?> 
                  <font face="Verdana">x <?php echo "$rupiah_affiliasi" ?></font></span></font></td>
                  <td align="right" width="113" height="1" bgcolor="#009999">
                  <font color="#FFFF00">
                  <span style="font-size: 8pt; font-weight:700" lang="id"><?php echo"$rupiah_total_bonus" ?></span></font></td>
                </tr>
              </table>
              </center>
          </div>
            <p style="line-height: 150%; margin-top: 0; margin-bottom: 0" align="center">&nbsp;</p>
            <div align="center">
              <center>
              <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="559" id="AutoNumber7" height="53">
                <tr>
                  <td width="172" height="19">
                  <span style="font-size: 8pt" lang="id"><b>Total Bonus</b> :</span></td>
                  <td width="387" height="19">
                  <span style="font-size: 8pt" lang="id"><b>
                  <font color="#008080"><?php echo"$rupiah_total_bonus" ?></font></b> </span></td>
                </tr>
                <tr>
                  <td width="172" height="1">
                  <span style="font-size: 8pt; font-weight: 700" lang="id">Yang 
                  sudah dibayarkan :</span></td>
                  <td width="387" height="1">
                  <span style="font-size: 8pt" lang="id"><font color="#008080">
                  <b><?php echo "$rupiah_bonus_terbayar" ?></b></font> <font color="#FF0000"></font> </span></td>
                </tr>
                <tr>
                  <td width="172" height="19">
                  <span style="font-size: 8pt; font-weight: 700" lang="id">Total Sisa 
                  Bonus :</span></td>
                  <td width="387" height="19">
                  <span style="font-size: 8pt" lang="id"><font color="#008080">
                  <b><?php echo"$rupiah_sisa_bayar_total" ?></b></font> <font color="#FF0000"></font> </span></td>
                </tr>
              </table>
              </center>
          </div>
            <p style="line-height: 150%; margin-top: 0; margin-bottom: 0" align="center">&nbsp;
            </p>
            <hr color="#CCCCCC" width="500" size="1">
            <p style="line-height: 150%; margin-top: 0; margin-bottom: 0" align="center">
            <font color="#FF0000" size="3"><b><span lang="id">DATA BANK MEMBER</span></b></font></p>
            <p style="line-height: 150%; margin-top: 0; margin-bottom: 0" align="center">
            <span lang="id">Nama Bank : <b><font color="#000080"><?php echo"{$datamember['nama_bank']}"   ?></font></b></span></p>
            <p style="line-height: 150%; margin-top: 0; margin-bottom: 0" align="center">
            <span lang="id">Rekening : <b><font color="#000080"><?php echo"{$datamember['rekening']}"   ?></font></b></span></p>
            <p style="line-height: 150%; margin-top: 0; margin-bottom: 0" align="center">
            <span lang="id">Cabang Bank : <b><font color="#000080"><?php echo"{$datamember['cabang_bank']}"   ?> </font>
            </b></span></p>
            <hr color="#CCCCCC" width="500" size="1">
            <p style="line-height: 150%; margin-top: 0; margin-bottom: 0" align="center">
            <span lang="id"><b>Setelah <u>melakukan transfer</u> bonus ke bank 
            member yang bersangkutan, silahkan input <i><font color="#FF0000">
            rincian bonusnya</font></i> pada form isian dibawah ini</b></span></p>
            <p style="line-height: 150%; margin-top: 0; margin-bottom: 0" align="center">
            <b><font color="#FF0000"><span lang="id">*) Perhatian !!! </span>
            </font></b></p>
            <p style="line-height: 150%; margin-top: 0; margin-bottom: 0" align="center">
            <span lang="id"><font color="#FF0000"><b>D</b></font></span><b><font color="#FF0000"><span lang="id">ata 
            ini amat <u>penting</u> dan <u>harus teliti</u> !!! </span></font>
            </b></p>
            <p style="line-height: 150%; margin-top: 0; margin-bottom: 0" align="center">&nbsp;</p>
            <hr color="#CCCCCC" width="500" size="1">
            <p style="line-height: 150%; margin-top: 0; margin-bottom: 0" align="center">
            <b><span lang="id">Input rincian transfer pembayaran <font color="#000080"> <u>bonus  </u></font></span></b></p>
            <form method="POST" action="admin_input_bonus.php">
            <p style="line-height: 150%; margin-top: 0; margin-bottom: 0" align="center">
              <span lang="id"><b>Rp.</b> </span>
              <input type="text" name="bayar_bonus" size="20"></p>
              <INPUT type="hidden" name="user1" value="<?php echo"$_GET[user]" ?>">
			  <INPUT type="hidden" name="sisa_bonus" value="<?php echo"$sisa_bayar_total" ?>">
              <p style="line-height: 150%; margin-top: 0; margin-bottom: 0" align="center">
              <font color="#FF0000"><span style="font-size: 8pt" lang="id">Tulis
              <u>tanpa</u> tanda titik dan koma (misal 12000)</span></font></p>
              <p style="line-height: 150%; margin-top: 0; margin-bottom: 0" align="center">
              <input type="submit" value="Submit" name="B1"></p>
          </form>
            
            </p>
            <hr color="#CCCCCC" width="500" size="1">
           <p>
            </p>
            <p style="line-height: 150%; margin-top: 0; margin-bottom: 0" align="center">&nbsp;</p>
            </td>
        </tr>
      </table>
      </center>
    </div>
    </td>
  </tr>
</table>

<p style="line-height: 100%; margin-top: 0; margin-bottom: 0">&nbsp;</p>
<p style="line-height: 100%; margin-top: 0; margin-bottom: 0">&nbsp;</p>

</body>

</html>
