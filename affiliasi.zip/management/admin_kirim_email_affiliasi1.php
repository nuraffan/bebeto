<?php 


	require( "../config_sis.php" );
	if( !verifyAdmin() ) header( "Location: index.php" );

			$subject = trim( $_POST['subject'] );
			$message = trim( $_POST['message'] );
                        $status = trim( $_POST['status'] );
			$rec_awal = trim( $_POST['rec_awal'] );
			$rec_akhir = trim( $_POST['rec_akhir'] );
			if( $subject == "" ) error( "Subject Masih Kosong !!!" );
			if( $message == "" ) error( "Pesan Masih Kosong !!!" );
			$pass = 0;
			$fail = 0;
			dbConnect();
			$nilai = mysql_query( "SELECT * FROM admin_affiliasi WHERE kode='$kode'" ) or error( mysql_error() );
                        $data = mysql_fetch_array( $nilai );
                        if( mysql_num_rows( $nilai ) != 1 ) error( "Ops ... ! Maaf Data administrator tidak ada," );
                        if ($status == "all" )
                        {
                          $result = mysql_query( "SELECT email, nama FROM affiliasi WHERE tanggal_join >= '$rec_awal' AND tanggal_join <= '$rec_akhir' " ) or error( mysql_error() );
                        }
                        else
                        {
			 $result = mysql_query( "SELECT email, nama FROM affiliasi WHERE stat1='$status' AND tanggal_join >= '$rec_awal' AND tanggal_join <= '$rec_akhir'" ) or error( mysql_error() );
                        }

			while( $row = mysql_fetch_array( $result ) )
			{
			    $nama=$row[nama];
			    $subject_1 = eregi_replace("%nama%","$nama",$subject);
			    $subject_2 = "$subject_1";
			    $message_1 = eregi_replace("%nama%","$nama",$message);
			    $message_2 = "$message_1";
		            $pesanBaru_1 = "----------------------->>$data[website]<<-----------------------------\n\n" . $message_2 . "\n\n";
                            $mailResult = sentMail( "$data[nama_bisnis] <$data[email_admin]>", $row['email'], $subject_2, $pesanBaru_1 );
										
				if( !$mailResult )
				{
					$fail += 1;
					$failEmail[] = $row['email'];
				}
				else
				{
					$pass += 1;
					$passEmail[] = $row['email'];
				}
				//$newMessage = "";
			}
			displayHeader( "Mailing List Result" );
			echo "<p align=\"center\"><font size=\"4\">:: Hasil Pengiriman ::</font></p>\n";
			echo "<div align=\"center\">\n";
			echo "  <center>\n";
			echo "  <table border=\"0\" width=\"400\" cellspacing=\"0\" cellpadding=\"0\">\n";
			echo "    <tr>\n";
			echo "      <td width=\"100%\" height=\"30\"><b>($pass)</b> Email Sukses Terkirim.</td>\n";
			echo "    </tr>\n";
			echo "    <tr>\n";
			echo "      <td width=\"100%\">\n";
			for( $i = 0; $i < count( $passEmail ); $i++ )
			{
				echo "      <li><a href=\"mailto:$passEmail[$i]\">$passEmail[$i]</a></li>\n";
			}
			echo "      </td>\n";
			echo "    </tr>\n";
			echo "    <tr>\n";
			echo "      <td width=\"100%\" height=\"30\"><b>($fail)</b> Email Tidak bisa terkirim.</td>\n";
			echo "    </tr>\n";
			echo "    <tr>\n";
			echo "      <td width=\"100%\">\n";
			for( $i = 0; $i < count( $failEmail ); $i++ )
			{
				echo "      <li><a href=\"mailto:$failEmail[$i]\">$failEmail[$i]</a></li>\n";
			}
			echo "      </td>\n";
			echo "    </tr>\n";
			echo "  </table>\n";
			echo "  </center>\n";
			echo "</div>\n";
			//echo "<p align=\"center\"><a href=\"admin.php?action=logout\"><b>Logout</b></a> | <a href=\"admin_menu.php\"><b>Back to Admin</b></a></p>\n";



?>