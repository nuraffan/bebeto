<?

	require( "../config_sis.php" );
        if( !verifyAdmin() ) 
	     {
	     header( "Location: ../index.php" );
	     return false;
	     }
       if ($_GET[user])
	    {
        dbConnect();
	    mysql_query( "DELETE FROM affiliasi WHERE username='$_GET[user]' " ) or error( mysql_error() );

        displayHeader( "Admin > Hapus Affiliasi" );
        echo "<p align=\"center\"><font size=\"2\">::: Menghapus Member Affiliasi Dengan Username : <b>$_GET[user]</b> Telah Sukses !!! :::</font></p>\n";
        //echo "<p align=\"center\"><a href=\"admin_menu.php\"><b>Back to Admin</b></a></p>\n";
       

        }
	
?>
