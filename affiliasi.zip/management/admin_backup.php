<?php 


   require( "../config_sis.php" );
   if( !verifyAdmin() )
	{
	header( "Location: ../index.php" );
	return false;
	}
   //if( !verifyAdmin() ) header( "Location: index.php" );
   // displayHeader( "Admin > Editing Admin" );
    dbConnect();
    $GZ_enabled = (bool) function_exists('gzencode');
    $backuptimestamp = date("ymd");
    $backupfilename = 'backup_database_'.$backuptimestamp.'.sql'.($GZ_enabled ? '.gz' : '');
    $fileheaderline .= '# ---------------------------------------'."\n";
    $fileheaderline .= '# Nama database : '.$dbName."\n";
    $fileheaderline .= '# Tanggal       : '.date('F j, Y g:i a')."\n";
    $fileheaderline .= '#----------------------------------------'."\n";
    $thistableinserts = $fileheaderline."\n";
    $tables = mysql_list_tables($dbName);
    if (is_resource($tables)) {
        while (list($table) = mysql_fetch_array($tables)) {
            
            $thistableinserts .= "# ---- Table `$table` -----"."\n";
            
            $result = mysql_query("SELECT * FROM $table");
            $insertstatement = "INSERT INTO `$table` VALUES (";
            unset($fieldnames);
            for ($i = 0; $i < mysql_num_fields($result); $i++) {
                $fieldnames[] = mysql_field_name($result, $i);
            }
            while ($row = mysql_fetch_array($result)) {
                unset($valuevalues);
                foreach ($fieldnames as $key => $val) {
                    if ($row[$key] === null) {
                        $valuevalues[] = 'NULL';
                    } else {
                        switch ($table[$val]) {
                            case 'tinyblob':
                            case 'blob':
                            case 'mediumblob':
                            case 'longblob':
                            $data = $row[$key];
                            $data_len = strlen($data);
                            if ($HexBLOBs && $data_len) {
                                $hexstring = '0x';
                                for ($i = 0; $i < $data_len; $i++) {
                                    $hexstring .= str_pad(dechex(ord($data {
                                        $i }
                                    )), 2, '0', STR_PAD_LEFT);
                                }
                                $valuevalues[] = $hexstring;
                            } else {
                                $valuevalues[] = '\''.mysql_escape_string($data).'\'';
                            }
                            break;
                            case 'tinyint':
                            case 'smallint':
                            case 'mediumint':
                            case 'int':
                            case 'bigint':
                            case 'float':
                            case 'double':
                            case 'decimal':
                            case 'year':
                            $valuevalues[] = mysql_escape_string($row[$key]);
                            break;
                            case 'varchar':
                            case 'char':
                            case 'tinytext':
                            case 'text':
                            case 'mediumtext':
                            case 'longtext':
                            case 'enum':
                            case 'set':
                            case 'date':
                            case 'datetime':
                            case 'time':
                            case 'timestamp':
                            default:
                            $valuevalues[] = '\''.mysql_escape_string($row[$key]).'\'';
                            break;
                        }
                    }
                }
                $thistableinserts .= $insertstatement.implode(', ', $valuevalues).');'."\n";
            }
        }
    }
    if ($GZ_enabled) {
        $dump_buffer = gzencode($thistableinserts);
    } else {
        $dump_buffer = $thistableinserts;
    }
    if (isset($HTTP_SERVER_VARS['HTTP_USER_AGENT']) and strpos($HTTP_SERVER_VARS['HTTP_USER_AGENT'], 'MSIE')) {
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Pragma: public');
        Header('Content-Type: application/force-download');
    } else {
        header('Pragma: no-cache');
        Header('Content-Type: application/octet-stream');
    }
    if (headers_sent())
    $this->Error('Some data has already been output to browser, can\'t send PDF file');
    Header('Content-Length: '.strlen($dump_buffer));
    Header('Content-disposition: attachment; filename='.$backupfilename);
    echo $dump_buffer;

?>