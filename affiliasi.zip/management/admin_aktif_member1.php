<?php 


require( "../config_sis.php" );
    if( !verifyAdmin() ) 
	{
	header( "Location: index.php" );
	return false;
	}

    if ($_GET['email'])
    {
    dbConnect();
    $result = mysql_query( "SELECT * FROM customer where email='$_GET[email]'" ) or error( mysql_error() );
    $reseller = mysql_fetch_array( $result );
	
    $result_1 = mysql_query( "SELECT * FROM affiliasi WHERE username='$reseller[username_sponsor]'" ) or error( mysql_error() );
    $member_1 = mysql_fetch_array( $result_1 );
			
    $nilai = mysql_query( "SELECT * FROM admin_affiliasi WHERE kode='$kode'" ) or error( mysql_error() );
    $data = mysql_fetch_array( $nilai );
    if( mysql_num_rows( $nilai ) != 1 ) error( "Ops ... ! Maaf Data administrator tidak ada !!!  " );
    $paid="paid";
    $stat="aktif";
    mysql_query( "UPDATE customer SET paid='$paid', stat='$stat' WHERE email='$_GET[email]' " ) or error( mysql_error() );
      
    require ("../email/email_aktivasi_member.php");
        
        
        displayHeader( "Admin > Member List" );
        echo "<p align=\"center\"><font size=\"3\">::: Mengaktifkan Member Dengan Email : <b>$_GET[email]</b> Telah Sukses !!! :::</font></p>\n";
      // echo "<p align=\"center\"><a href=\"admin_menu.php\"><b>Back to Admin</b></a></p>\n";

        }
	
;echo '
';
?>