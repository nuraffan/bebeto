<STYLE>BODY {
	SCROLLBAR-FACE-COLOR: #000000; SCROLLBAR-HIGHLIGHT-COLOR: #006699; SCROLLBAR-SHADOW-COLOR: #006699; SCROLLBAR-3DLIGHT-COLOR: #006699; SCROLLBAR-ARROW-COLOR: #ffffff ; SCROLLBAR-TRACK-COLOR: #C0C0C0; SCROLLBAR-DARKSHADOW-COLOR: #006699; SCROLLBAR-BASE-COLOR: #006699}
.lnk1:hover {
	COLOR: #0000fa; TEXT-DECORATION: none
}
.lnk:link {
	COLOR: #ffff00; TEXT-DECORATION: none
}

</STYLE>
<?php 

// #-------------------------- Script Indo Affiliate 2008 Ver 1.0 ---------------#
// #------------------- Copyright � 2008 Ali Rasbany - Yogyakarta  --------------#
// #------------------------ http://www.superautopilot.com  ---------------------#
// #----------------------- Protected By Indonesian Law  ------------------------#

require( "../config_sis.php" );
if( !verifyAdmin() ) 
	{
	header( "Location: index.php" );
	return false;
	}
//if( !verifyAdmin() ) header( "Location: index.php" );
$membersPage = 50;
$id = @mysql_connect($dbHost,$dbUser,$dbPasswd);
$db = @mysql_select_db($dbName,$id);
function buildLeadIndex($qty, $membersPage) {
	if($qty > $membersPage) {
		echo "<b>Halaman :</b> ";
		$index = 0;
		$start = 0;
		while($qty > 0) {
			echo ' [<a href="admin_statistik.php?start='.$start.'">'.++$index.'</a>]';
			$qty = $qty - $membersPage;
			$start = $start + $membersPage;
		}
	}

}

if($id == 0 || $db == 0) {
// Problems with MySQL connection
error( mysql_error());
exit;
 }

// incoming vars
// $_REQUEST[act, lID, start]
if($_REQUEST[act] == 'lDel') {

	$l = $_REQUEST[user_id];
	for($i = 0; $i < count($l); $i++) {
		mysql_query("DELETE FROM statistik WHERE user_id=$l[$i]",$id);
	}
}

// $_REQUEST[action, start]
if($_REQUEST[action] == 'yes') {

        $l = $_REQUEST[user_id];
	for($i = 0; $i < count($l); $i++) {
		mysql_query("DELETE FROM statistik WHERE user_id=$l[$i]",$id);
	}

}

if($_REQUEST[action] == 'no') {

        mysql_query("DELETE FROM statistik ");
           }

// get total members
$qryT = mysql_query("SELECT * FROM statistik",$id);
$totalMember = mysql_num_rows($qryT);

// get members
if($_REQUEST[start]) { $start = $_REQUEST[start]; }
else { $start = 0; }

$qry = mysql_query("SELECT * FROM statistik ORDER BY user_id DESC LIMIT $start,$membersPage",$id);
$qry1 = mysql_query("SELECT * FROM statistik ORDER BY user_id DESC LIMIT $start,$membersPage",$id);
;echo ''; displayHeader( "Admin > All Member List" );

echo "<p style=\"margin-top: 0; margin-bottom: 0\" align=\"center\"><font size=\"1\"><b>Statistik Total $totalMember hits </b></font></p>\n";
echo "<p style=\"margin-top: 0; margin-bottom: 0\" align=\"center\"><font size=\"1\">Daftar dibawah ini adalah jumlah dari keseluruhan kunjungan pada website. Anda bisa mendelete satu persatu <b> Delete Checked</b> Atau <b>Delete All</b>.</font></p>\n"; ;echo '<html>
<head>
<link rel="stylesheet" href="styles.css" type="text/css">
<style>
td {padding-bottom:5px; border-bottom: 1px solid #CCCCCC;}
</style>
</head>
<body id="text">

'; buildLeadIndex($totalMember, $membersPage); ;echo '';
// Tampilkan Member
if(mysql_num_rows($qry) > 0) {

	// header
	echo "<div align=\"center\"><small>\n";
	echo '<form method="post" action="admin_statistik.php">';
	echo '<table id="text" style="width:100%;">';
	echo '<tr style="background:#C0C0C0;"><td style="width:20px;"><small>CHECK</small></td><td>';
	echo '<small>ID </small></td><td><small>WAKTU</small></td><td><small>IP ADD</small></td><td><small>URL</small></td><td><small>REFERENSI</small></td><td><small>AFFILIASI</small></td></tr>';

	// body
	while($row = mysql_fetch_array($qry)) {
	echo '<tr><td><input type="checkbox" name="user_id[]" value="'.$row[user_id].'"></td>';
	echo '<td><small>',$row[user_id],'</small></td>';
	echo '<td><small>',$row[time],'</small></td>';
	echo '<td><small>',$row[ip_add],'</small></td>';
	echo '<td><small>',$row[url],'</small></td>';
        echo '<td><small>',$row[ref],'</small></td>';
        echo '<td><small>',$row[username],'</small></td></tr>';
      	}
  	echo '<tr style="background:#C0C0C0;"><td style="width:20px;"><small>CHECK</small></td><td>';
        echo '<small>ID </small></td><td><small>WAKTU</small></td><td><small>IP ADD</small></td><td><small>URL</small></td><td><small>REFERENSI</small></td><td><small>AFFILIASI</small></td></tr>';


	// bottom
	echo '</table><br>';
	echo '<input type="submit" value="Delete Checked" id="button">';
	echo '<input type="hidden" name="act" value="lDel">';
	echo '<input type="hidden" name="start" value="'.$_REQUEST[start].'">';
	echo '</form>';
        //========================
        
         echo '<form method="post" action="admin_statistik.php">';

        while($row = mysql_fetch_array($qry1)) {
	       echo '<input type="hidden" name="user_id[]" value="'.$row[user_id].'"></td>';
                  	}
        echo '<input type="hidden" name="action" value="yes">';
        echo '<input type="hidden" name="start" value="'.$_REQUEST[start].'">';
        echo '<input type="submit" value="Hapus data pada halaman ini" id="button">';
        echo '</form>';
        
        //========================

        echo '<form method="post" action="admin_statistik.php">';
        echo '<input type="hidden" name="action" value="no">';
        echo '<input type="hidden" name="start" value="'.$_REQUEST[start].'">';
        echo '<input type="submit" value="Hapus Semua Data" id="button">';
        echo '</form>';

 

} else {
	echo 'Data Masih Kosong';
}

       // echo "<p align=\"center\"><font size=\"2\"><a href=\"admin_menu.php \"><b>Back to Admin</b></a></p>\n";
;echo '
';
?>