<STYLE>BODY {
	SCROLLBAR-FACE-COLOR: #000000; SCROLLBAR-HIGHLIGHT-COLOR: #006699; SCROLLBAR-SHADOW-COLOR: #006699; SCROLLBAR-3DLIGHT-COLOR: #006699; SCROLLBAR-ARROW-COLOR: #ffffff ; SCROLLBAR-TRACK-COLOR: #C0C0C0; SCROLLBAR-DARKSHADOW-COLOR: #006699; SCROLLBAR-BASE-COLOR: #006699}
.lnk1:hover {
	COLOR: #0000fa; TEXT-DECORATION: none
}
.lnk:link {
	COLOR: #ffff00; TEXT-DECORATION: none
}

</STYLE>
<?

require( "../config_sis.php" );
if( !verifyAdmin() ) 
	{
	header( "Location: ../index.php" );
	return false;
	}
//if( !verifyAdmin() ) header( "Location: index.php" );
$TestiPage = 10;
$id = @mysql_connect($dbHost,$dbUser,$dbPasswd);
$db = @mysql_select_db($dbName,$id);
function buildLeadIndex($qty, $TestiPage) {
	if($qty > $TestiPage) {
		echo "Halaman : ";
		$index = 0;
		$start = 0;
		while($qty > 0) {
			echo ' <a href="admin_testimonial.php?start='.$start.'">'.++$index.'</a>';
			$qty = $qty - $TestiPage;
			$start = $start + $TestiPage;
		}
	}

}

if($id == 0 || $db == 0) {
// Problems with MySQL connection
error( mysql_error());
exit;
 }

// incoming vars
// $_REQUEST[act, lID, start]
if($_REQUEST[act] == 'lDel') {

	$l = $_REQUEST[user_id];
	for($i = 0; $i < count($l); $i++) {
		mysql_query("DELETE FROM testimonial WHERE user_id=$l[$i]",$id);
	}
}

// get total Testimonial
$qryT = mysql_query("SELECT * FROM testimonial",$id);
$totalTesti = mysql_num_rows($qryT);

// get Testimonial
if($_REQUEST[start]) { $start = $_REQUEST[start]; }
else { $start = 0; }

$qry = mysql_query("SELECT * FROM testimonial ORDER BY user_id DESC LIMIT $start,$TestiPage",$id);

?>
<? displayHeader( "Admin > Testimonial" );
echo "<p style=\"margin-top: 0; margin-bottom: 0\" align=\"center\"><font size=\"1\" ><b>Halaman Input dan Delete Testimonial Website anda </b></font></p>\n";
echo "<p style=\"margin-top: 0; margin-bottom: 0\" align=\"center\"><font size=\"2\" ><b>Jumlah Semua Testimonial : $totalTesti </b></font></p>\n";
echo "<p style=\"margin-top: 0; margin-bottom: 0\" align=\"center\"><font size=\"1\" color=\"#000080\"><i>Daftar dibawah ini adalah jumlah dari keseluruhan Testimonial dari website ini yang akan ditampilkan pada halaman Testimonial di Website utama, anda bisa men-<b>deletenya</b> melalui halaman ini. Caranya Check pada kotak yang disediakan kemudian klik DELETE CHECKED dibawah</i></font></p>\n"; ?>
<html>
<head>
<style>
td {padding-bottom:5px; border-bottom: 1px solid #CCCCCC;}
</style>
</head>
<body id="text">
<? buildLeadIndex($totalTesti, $TestiPage); ?>
<?
// Tampilkan Testimonial
if(mysql_num_rows($qry) > 0) {

	// header
   echo "<div align=\"center\"><small>\n";
   echo '<form method="post" action="admin_testimonial.php">';
	
   // body
   while($row = mysql_fetch_array($qry)) {
   echo "<p style=\"margin-top: 0; margin-bottom: 0\" align=\"justify\"><input type=\"checkbox\" name=\"user_id[]\" value=\"$row[user_id]\">\n";
   echo "<p style=\"margin-top: 0; margin-bottom: 0\" align=\"justify\"><b><font face=\"Verdana\" size=\"1\" color=\"#000080\"> $row[judul]</font></b></p>\n";
   echo "<p style=\"margin-top: 0; margin-bottom: 0\" align=\"justify\"><font face=\"Verdana\" size=\"1\">$row[isi]</font></p>\n";
   echo "<p style=\"margin-top: 0; margin-bottom: 0\" align=\"justify\"><i><font face=\"Verdana\" size=\"1\" color=\"#FF0000\"> $row[nama] - $row[kota]</font></i></p>\n";
   echo "<p style=\"margin-top: 0; margin-bottom: 0\" align=\"justify\"><font face=\"Verdana\" size=\"1\">$row[email]</font></p>\n";
   echo "<p style=\"margin-top: 0; margin-bottom: 0\" align=\"justify\"><font face=\"Verdana\" size=\"1\">\n";
   echo "<hr color=\"#000000\" size=\"1\"></font></p>\n";
       
	  }
  
	// bottom
	echo '</table><br>';
	echo '<input type="submit" value="Delete Checked" id="button">';
	echo '<input type="hidden" name="act" value="lDel">';
	echo '<input type="hidden" name="start" value="'.$_REQUEST[start].'">';
	echo '</form>';
	
	

} 
else 
{
	echo "<p align=\"center\"><font size=\"3\"><font color=\"#FF0000\"><b>Belum Ada Testimonial !!! </b></font></p>\n";
	
}
?>
<p align="center" style="margin-top: 0; margin-bottom: 0">
<font face="Verdana" size="2"><font color="#CC3300">Masukkan testimonial (kesaksian) tentang produk
 disini</font></p>
<p align="center" style="margin-top: 0; margin-bottom: 0"></p>
<div align="center">
  <center>
  <table borderColor="#CC0000" border="2" cellpadding="2" cellspacing="0" width="557" id="AutoNumber1">
    <tr>
     <form action="admin_testimonial2.php" method="post">

                  <td width="551" bgColor="#F3F5F7" height="83">&nbsp;
                  <div align="center">
                    <table height="1" cellSpacing="0" cellPadding="0" width="537" border="0">
                      <tr>
                        <td width="211" height="9">
                        <font face="Verdana" size="1"><b>Nama :</b></font></td>
                        <td width="349" height="9"><font face="Verdana">
                        <input size="25" name="nama" style="border-style: inset; border-width: 1; padding: 0; background-color: #F5F5EB"> </font></td>
                      </tr>
                      <tr>
                        <td width="211" height="25">
                        <b><font face="Verdana" size="1">Kota :</font></b></td>
                        <td width="349" height="25"><font face="Verdana">
                        <input size="25" name="kota" style="border-style: inset; border-width: 1; padding: 0; background-color: #F5F5EB"> </font></td>
                         </tr>
                      <tr>
                        <td width="211" height="25">
                        <b><font face="Verdana" size="1">Email :</font></b></td>
                        <td width="349" height="25"><font face="Verdana">
                        <input size="25" name="email" style="border-style: inset; border-width: 1; padding: 0; background-color: #F5F5EB"> </font></td>
                         </tr>
                      <tr>
                         <input type="hidden" value="<? echo "$session_username" ?>" name="username">
                      </tr>
                      <tr>
                        <td width="211" height="1">
                        <b><font face="Verdana" size="1">Judul :</font></b></td>
                        <td width="349" height="1"><font face="Verdana">
                        <input size="57" name="judul" style="border-style: inset; border-width: 1; padding: 0; background-color: #F5F5EB"></font></td>
                      </tr>
                      <tr>
                        <td width="211" height="25">
                        <b><font face="Verdana" size="1">Masukkan testimonial
                        disini</font></b></td>
                        <td width="447" height="25"><font face="Verdana">
                        <textarea rows="5" name="isi" cols="49" style="border-style: inset; border-width: 1; padding: 0; background-color: #F5F5EB"></textarea>&nbsp;</font></td>
                      </tr>
                      <tr>
                        <td vAlign="center" width="525" colSpan="2" height="1">
                        </td>
                      </tr>
                      <tr>
                        <td width="525" colSpan="2" height="26">
                        <blockquote>
                          <p align="center"><font face="Verdana">&nbsp;&nbsp;</font> </p>
                        </blockquote>



                        <p align="center"><font face="Verdana">
                        <input type="submit" value="POST TESTIMONIAL >>" name="Submit" style="font-family: Tahoma; font-size: 12px; border-style: outset; border-width: 2">
                        </font></td>
                      </tr>
                      <tr>
                        <td width="525" colSpan="2" height="1">
                        <font face="Verdana" color="#ffffff">.</font> </td>
                      </tr>
                    </table>
                  </div>
                  </td>
                  </form>
                </tr>
  </table>
  </center>
</div>
<p align="center" style="margin-top: 0; margin-bottom: 0">&nbsp;</p>


<?

   //echo "<p align=\"center\"><font size=\"2\"><a href=\"admin_menu.php\"><b>Back to Admin</b></a></p>\n";
?>
</body>
</html>
















